import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, FileText, PencilLine, TrendingDown } from "lucide-react";
import {
  BENCHMARKS,
  CATEGORY_META,
  getSuggestions,
  type CalcInputs,
  type CalcResults,
} from "@/data/calculator";
import { fmtKg, fmtTonnes } from "@/utils/format";

const SCALE_MAX = 16;

interface ResultsPanelProps {
  inputs: CalcInputs;
  results: CalcResults;
  submitted: boolean;
  onSubmit: () => void;
  onEdit: () => void;
}

function Bar({ pct, color, delay = 0, highlight = false }: { pct: number; color: string; delay?: number; highlight?: boolean }) {
  return (
    <div className="h-2 overflow-hidden rounded-full bg-cream-deep">
      <motion.div
        className={`h-full origin-left rounded-full ${highlight ? "shadow-[0_0_12px_rgba(45,106,79,0.35)]" : ""}`}
        style={{ background: color }}
        initial={{ scaleX: 0 }}
        animate={{ scaleX: Math.max(0.015, pct / 100) }}
        transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
      />
    </div>
  );
}

export function ResultsPanel({ inputs, results, submitted, onSubmit, onEdit }: ResultsPanelProps) {
  const suggestions = getSuggestions(inputs);
  const vsGlobal = ((results.totalTonnes - 4.7) / 4.7) * 100;
  const pathMultiple = results.totalTonnes / 2.5;
  const treeEquivalent = Math.round(results.totalKg / 21);
  const milesEquivalent = Math.round(results.totalKg / 0.4);

  return (
    <AnimatePresence mode="wait">
      {!submitted ? (
        <motion.div
          key="summary"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-3xl border border-line bg-white/80 p-6 shadow-card sm:p-8"
          aria-label="Live estimate"
        >
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-mist">Live estimate</p>
          <p className="mt-2 text-xs text-forest-700">Numbers update as you answer</p>

          <div className="mt-4 flex items-baseline gap-2">
            <span className="tnum font-display text-6xl font-light tracking-tight text-forest-950">
              {fmtTonnes(results.totalTonnes)}
            </span>
            <span className="text-sm text-mist">t CO₂e / year</span>
          </div>

          <div className="mt-6 space-y-3.5">
            {results.categories.map((c) => {
              const meta = CATEGORY_META[c.key];
              return (
                <div key={c.key}>
                  <div className="flex items-baseline justify-between text-[13px]">
                    <span className="flex items-center gap-2 text-ink/75">
                      <meta.icon className="h-3.5 w-3.5" style={{ color: meta.color }} strokeWidth={1.8} />
                      {c.label}
                    </span>
                    <span className="tnum text-xs text-mist">{Math.round(c.pct)}%</span>
                  </div>
                  <div className="mt-1.5">
                    <Bar pct={c.pct} color={meta.color} />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-7 border-t border-line pt-6">
            <button type="button" onClick={onSubmit} className="btn-primary group w-full py-3.5">
              <FileText className="h-4 w-4" />
              Generate my full report
            </button>
            <p className="mt-3 text-center text-xs text-mist">
              Free · no account · your data stays in this browser
            </p>
          </div>
        </motion.div>
      ) : (
        <motion.div
          key="report"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-3xl border border-line bg-white/80 p-6 shadow-card sm:p-8"
          aria-label="Your carbon report"
        >
          {/* Headline */}
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-mist">Your annual footprint</p>
          <div className="mt-3 flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <span className="tnum font-display text-[3.2rem] font-light leading-none tracking-tight text-forest-950">
              {fmtTonnes(results.totalTonnes)}
            </span>
            <span className="text-base text-mist">t CO₂e per person</span>
          </div>
          <p className="mt-2 text-xs text-mist">
            Based on a household of {inputs.householdSize} · emissions shared per person
          </p>

          <div
            className={`mt-4 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ${
              vsGlobal <= 0
                ? "bg-forest-600/10 text-forest-800"
                : "border border-[#c87f4f]/30 bg-[#c87f4f]/10 text-[#a55f2e]"
            }`}
          >
            <TrendingDown className={`h-3.5 w-3.5 ${vsGlobal > 0 ? "rotate-180" : ""}`} />
            {vsGlobal <= 0
              ? `${Math.abs(vsGlobal).toFixed(0)}% below the global average`
              : `${vsGlobal.toFixed(0)}% above the global average`}
            <span className="font-normal opacity-70">· {pathMultiple.toFixed(1)}× the 1.5 °C path</span>
          </div>

          {/* Equivalents */}
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-line bg-cream p-3.5">
              <p className="tnum text-lg font-semibold text-forest-950">{milesEquivalent.toLocaleString()} mi</p>
              <p className="mt-0.5 text-[11px] leading-snug text-mist">driven in an average petrol car</p>
            </div>
            <div className="rounded-2xl border border-line bg-cream p-3.5">
              <p className="tnum text-lg font-semibold text-forest-950">{treeEquivalent.toLocaleString()}</p>
              <p className="mt-0.5 text-[11px] leading-snug text-mist">tree seedlings growing for 10 years</p>
            </div>
          </div>

          {/* Benchmarks */}
          <div className="mt-7">
            <h4 className="text-sm font-semibold text-forest-950">How you compare</h4>
            <div className="mt-4 space-y-3.5">
              {[{ label: "Your estimate", tonnes: results.totalTonnes, note: "", highlight: true }, ...BENCHMARKS.map((b) => ({ ...b, highlight: false }))].map(
                (row, i) => (
                  <div key={row.label}>
                    <div className="flex items-baseline justify-between gap-3 text-[13px]">
                      <span className={row.highlight ? "font-semibold text-forest-950" : "text-ink/70"}>
                        {row.label}
                      </span>
                      <span className={`tnum text-xs ${row.highlight ? "font-semibold text-forest-900" : "text-mist"}`}>
                        {fmtTonnes(row.tonnes, 1)} t
                        {row.note ? <span className="ml-1.5 text-[10px] text-mist/70">{row.note}</span> : null}
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <Bar
                        pct={(row.tonnes / SCALE_MAX) * 100}
                        color={row.highlight ? "#1b4332" : "#b9c4b0"}
                        delay={0.08 * i}
                        highlight={row.highlight}
                      />
                    </div>
                  </div>
                )
              )}
            </div>
          </div>

          {/* Category breakdown */}
          <div className="mt-7">
            <h4 className="text-sm font-semibold text-forest-950">Where it comes from</h4>
            <div className="mt-4 space-y-3.5">
              {results.categories.map((c, i) => {
                const meta = CATEGORY_META[c.key];
                return (
                  <div key={c.key}>
                    <div className="flex items-baseline justify-between gap-3 text-[13px]">
                      <span className="flex items-center gap-2 text-ink/75">
                        <meta.icon className="h-3.5 w-3.5" style={{ color: meta.color }} strokeWidth={1.8} />
                        {c.label}
                      </span>
                      <span className="tnum text-xs text-mist">
                        {fmtKg(c.kg)} · {Math.round(c.pct)}%
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <Bar pct={c.pct} color={meta.color} delay={0.1 + i * 0.07} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Suggestions */}
          <div className="mt-8">
            <h4 className="text-sm font-semibold text-forest-950">Your reduction playbook</h4>
            <p className="mt-1 text-xs text-mist">Ranked by what would move your number most</p>
            <ul className="mt-4 space-y-3">
              {suggestions.map((s, i) => (
                <motion.li
                  key={s.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, delay: 0.25 + i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                  className="flex gap-3.5 rounded-2xl border border-line bg-cream/80 p-4"
                >
                  <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-forest-800/10 text-forest-800">
                    <s.icon style={{ width: 18, height: 18 }} strokeWidth={1.8} />
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="chip border-forest-600/20 bg-forest-600/10 px-2 py-0.5 text-[10px] text-forest-800">
                        {s.tag}
                      </span>
                      {s.savingTonnes > 0 ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-forest-700">
                          <TrendingDown className="h-3 w-3" />−{fmtTonnes(s.savingTonnes)} t / yr
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1.5 text-sm font-medium leading-snug text-forest-950">{s.title}</p>
                    <p className="mt-1 text-xs leading-relaxed text-mist">{s.body}</p>
                  </div>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Actions */}
          <div className="mt-7 flex flex-col gap-3 border-t border-line pt-6 sm:flex-row">
            <button type="button" onClick={onEdit} className="btn-outline flex-1 py-3">
              <PencilLine className="h-4 w-4" />
              Adjust my answers
            </button>
            <Link to="/dashboard" className="btn-primary group flex-1 py-3">
              Track this monthly
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
          </div>

          <p className="mt-5 text-[11px] leading-relaxed text-mist/80">
            Estimate only — factors from EPA (2024), DEFRA (2025) and Exiobase 3.8.
            A synced account narrows accuracy to roughly ±5%.
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
