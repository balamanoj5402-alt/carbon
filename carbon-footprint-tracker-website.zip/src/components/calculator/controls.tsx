import type { CSSProperties } from "react";
import { motion } from "framer-motion";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* Slider row                                                          */
/* ------------------------------------------------------------------ */

interface SliderRowProps {
  id: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  hint?: string;
  onChange: (v: number) => void;
}

export function SliderRow({ id, label, value, min, max, step = 1, unit, hint, onChange }: SliderRowProps) {
  const pct = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  return (
    <div>
      <div className="flex items-baseline justify-between gap-4">
        <label htmlFor={id} className="text-sm font-medium text-ink/85">
          {label}
        </label>
        <span className="tnum whitespace-nowrap rounded-lg bg-sage-100 px-2.5 py-1 text-sm font-semibold text-forest-900">
          {value.toLocaleString("en-US")}
          {unit ? ` ${unit}` : ""}
        </span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="v-range mt-3.5"
        style={{ "--fill": `${pct}%` } as CSSProperties}
        aria-valuetext={`${value}${unit ?? ""}`}
      />
      {hint ? <p className="mt-2 text-xs leading-relaxed text-mist">{hint}</p> : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Segmented control                                                   */
/* ------------------------------------------------------------------ */

interface SegmentedOption<T extends string> {
  value: T;
  label: string;
  blurb?: string;
}

interface SegmentedControlProps<T extends string> {
  id: string;
  label: string;
  value: T;
  options: SegmentedOption<T>[];
  onChange: (v: T) => void;
}

export function SegmentedControl<T extends string>({ id, label, value, options, onChange }: SegmentedControlProps<T>) {
  const active = options.find((o) => o.value === value);
  return (
    <div>
      <span className="text-sm font-medium text-ink/85">{label}</span>
      <div role="radiogroup" aria-label={label} className="mt-3 flex flex-wrap gap-2">
        {options.map((o) => {
          const isActive = o.value === value;
          return (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={isActive}
              onClick={() => onChange(o.value)}
              className={cn(
                "relative rounded-full border px-4 py-2 text-sm transition-colors duration-300",
                isActive
                  ? "border-forest-800 text-cream"
                  : "border-line bg-white/60 text-mist hover:border-forest-700/50 hover:text-forest-900"
              )}
            >
              {isActive && (
                <motion.span
                  layoutId={`seg-${id}`}
                  className="absolute inset-0 rounded-full bg-forest-800"
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                />
              )}
              <span className="relative">{o.label}</span>
            </button>
          );
        })}
      </div>
      {active?.blurb ? (
        <p className="mt-2.5 text-xs leading-relaxed text-mist" aria-live="polite">
          {active.blurb}
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Stepper                                                             */
/* ------------------------------------------------------------------ */

interface StepperProps {
  id: string;
  label: string;
  value: number;
  min?: number;
  max?: number;
  hint?: string;
  onChange: (v: number) => void;
}

export function Stepper({ id, label, value, min = 0, max = 99, hint, onChange }: StepperProps) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <span id={`${id}-label`} className="text-sm font-medium text-ink/85">{label}</span>
        {hint ? <p className="mt-1 text-xs leading-relaxed text-mist">{hint}</p> : null}
      </div>
      <div className="flex shrink-0 items-center gap-2.5" role="group" aria-labelledby={`${id}-label`} aria-label={`${label}: ${value}`}>
        <button
          type="button"
          aria-label={`Decrease ${label}`}
          onClick={() => onChange(Math.max(min, value - 1))}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line bg-white/60 text-forest-900 transition-all duration-200 hover:border-forest-700/60 hover:bg-sage-100 active:scale-95"
        >
          <Minus className="h-4 w-4" />
        </button>
        <span className="tnum w-8 text-center text-base font-semibold text-forest-950">{value}</span>
        <button
          type="button"
          aria-label={`Increase ${label}`}
          onClick={() => onChange(Math.min(max, value + 1))}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line bg-white/60 text-forest-900 transition-all duration-200 hover:border-forest-700/60 hover:bg-sage-100 active:scale-95"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
