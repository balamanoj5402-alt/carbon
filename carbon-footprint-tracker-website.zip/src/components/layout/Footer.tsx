import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { SOCIALS } from "@/data/site";
import { BrandIcon } from "@/components/ui/BrandIcons";
import { Logo } from "@/components/ui/Logo";

const COLUMNS: { title: string; links: { label: string; to: string }[] }[] = [
  {
    title: "Product",
    links: [
      { label: "Carbon calculator", to: "/calculator" },
      { label: "Live dashboard", to: "/dashboard" },
      { label: "Method & data", to: "/about#method" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "Our mission", to: "/about" },
      { label: "Contact", to: "/about#contact" },
      { label: "Newsletter", to: "/about#newsletter" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Impact report", to: "/about#impact" },
      { label: "Team challenges", to: "/dashboard" },
      { label: "Reduction guides", to: "/calculator" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-forest-950 text-cream">
      {/* soft glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 h-96 w-[42rem] -translate-x-1/2 rounded-full bg-forest-600/15 blur-3xl"
      />

      <div className="container-x relative">
        {/* Editorial CTA strip */}
        <div className="border-b border-white/10 py-14">
          <Link to="/calculator" className="group flex items-center justify-between gap-6">
            <h3 className="max-w-xl font-display text-3xl font-light leading-tight text-cream sm:text-4xl">
              Start measuring what matters.
            </h3>
            <span className="inline-flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-white/20 text-sage-300 transition-all duration-300 group-hover:-translate-y-1 group-hover:border-sage-300 group-hover:bg-sage-300/10 sm:h-16 sm:w-16">
              <ArrowUpRight className="h-6 w-6 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </span>
          </Link>
        </div>

        {/* Main grid */}
        <div className="grid gap-12 py-14 md:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div className="max-w-sm">
            <Logo tone="dark" />
            <p className="mt-5 text-sm leading-relaxed text-cream/60">
              The carbon intelligence platform for people who want answers, not
              guilt. Science-backed data, honest benchmarks, and a plan that
              actually bends your curve.
            </p>
            <div className="mt-6 flex items-center gap-2.5">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Verdant on ${s.label}`}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-cream/70 transition-all duration-300 hover:-translate-y-0.5 hover:border-sage-300 hover:text-sage-300"
                >
                  <BrandIcon brand={s.brand} className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h4 className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cream/40">
                {col.title}
              </h4>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      to={l.to}
                      className="group inline-flex items-center gap-1.5 text-sm text-cream/65 transition-colors duration-200 hover:text-cream"
                    >
                      <span className="h-px w-0 bg-sage-300 transition-all duration-300 group-hover:w-4" />
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col gap-3 border-t border-white/10 py-7 text-xs text-cream/40 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Verdant Earth AB · Copenhagen, Denmark</p>
          <p className="flex flex-wrap items-center gap-x-1.5 gap-y-1">
            Factors: EPA · DEFRA · Exiobase · IPCC
            <span className="mx-1 inline-block h-1 w-1 rounded-full bg-cream/30" />
            <a href="mailto:hello@verdant.earth" className="transition-colors hover:text-cream">
              hello@verdant.earth
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
