import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

interface PageProps {
  children: ReactNode;
  className?: string;
}

/** Route-level transition wrapper: subtle rise + fade on navigation. */
export function Page({ children, className = "" }: PageProps) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: reduce ? 0 : 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: reduce ? 0 : -10 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
