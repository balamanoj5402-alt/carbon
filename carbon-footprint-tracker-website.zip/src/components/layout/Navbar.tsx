import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Menu, X } from "lucide-react";
import { NAV_ITEMS } from "@/data/site";
import { Logo } from "@/components/ui/Logo";
import { cn } from "@/utils/cn";

export function Navbar() {
  const { pathname } = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const isHome = pathname === "/";
  const solid = !isHome || scrolled || open;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const linkCls = ({ isActive }: { isActive: boolean }) =>
    cn(
      "relative rounded-full px-1 py-2 text-sm transition-colors duration-200",
      isActive
        ? solid
          ? "text-forest-900"
          : "text-cream"
        : solid
          ? "text-mist hover:text-forest-900"
          : "text-cream/75 hover:text-cream"
    );

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[80] transition-colors duration-500",
        solid ? "border-b border-line bg-cream/85 shadow-[0_8px_30px_-18px_rgba(11,29,20,0.25)] backdrop-blur-xl" : "border-b border-transparent bg-transparent"
      )}
    >
      <div className="container-x flex h-[72px] items-center justify-between gap-6">
        <Link to="/" aria-label="Verdant — home" className="shrink-0">
          <Logo tone={solid ? "light" : "dark"} />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary">
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.to === "/"} className={linkCls}>
              {({ isActive }) => (
                <>
                  {item.label}
                  {isActive && (
                    <motion.span
                      layoutId="nav-underline"
                      className={cn(
                        "absolute inset-x-1 -bottom-0.5 h-px",
                        solid ? "bg-forest-700" : "bg-sage-300"
                      )}
                      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                    />
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Link
            to="/dashboard"
            className={
              solid
                ? "btn-ghost"
                : "rounded-full px-5 py-2.5 text-sm text-cream/85 transition-colors hover:text-cream"
            }
          >
            View demo
          </Link>
          <Link to="/calculator" className="btn-primary group">
            Start tracking
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          className={cn(
            "inline-flex h-10 w-10 items-center justify-center rounded-full border transition-colors md:hidden",
            solid
              ? "border-forest-800/20 text-forest-900 hover:bg-forest-800/5"
              : "border-white/25 text-cream hover:bg-white/10"
          )}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden border-b border-line bg-cream/95 backdrop-blur-xl md:hidden"
          >
            <nav className="container-x flex flex-col gap-1 py-5" aria-label="Mobile">
              {NAV_ITEMS.map((item, idx) => (
                <motion.div
                  key={item.to}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.06 + idx * 0.05, duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                >
                  <NavLink
                    to={item.to}
                    end={item.to === "/"}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center justify-between rounded-xl px-4 py-3 text-lg transition-colors",
                        isActive
                          ? "bg-forest-800/5 font-medium text-forest-900"
                          : "text-mist hover:bg-forest-800/5 hover:text-forest-900"
                      )
                    }
                  >
                    {item.label}
                    <ArrowRight className="h-4 w-4 opacity-40" />
                  </NavLink>
                </motion.div>
              ))}
              <div className="mt-3 flex flex-col gap-2.5 border-t border-line pt-4">
                <Link to="/dashboard" className="btn-outline w-full">
                  View live demo
                </Link>
                <Link to="/calculator" className="btn-primary w-full">
                  Start tracking
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
