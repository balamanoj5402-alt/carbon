import type { ReactNode } from "react";
import { Reveal } from "./Reveal";

interface SectionHeadingProps {
  eyebrow: string;
  title: ReactNode;
  description?: string;
  align?: "left" | "center";
  dark?: boolean;
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  dark = false,
  className = "",
}: SectionHeadingProps) {
  const alignment = align === "center" ? "items-center text-center" : "items-start text-left";
  return (
    <div className={`flex flex-col gap-4 ${alignment} ${className}`}>
      <Reveal>
        <span
          className={`inline-flex items-center gap-2.5 text-[11px] font-semibold uppercase tracking-[0.26em] ${
            dark ? "text-sage-300" : "text-forest-700"
          }`}
        >
          <span className={`h-px w-8 ${dark ? "bg-sage-300/60" : "bg-forest-600/50"}`} />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          className={`max-w-2xl text-3xl font-light leading-[1.12] tracking-[-0.01em] sm:text-4xl lg:text-[2.75rem] ${
            dark ? "text-cream" : "text-forest-950"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {description ? (
        <Reveal delay={0.16}>
          <p className={`max-w-xl text-[15px] leading-relaxed sm:text-base ${dark ? "text-cream/70" : "text-mist"}`}>
            {description}
          </p>
        </Reveal>
      ) : null}
    </div>
  );
}
