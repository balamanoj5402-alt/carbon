interface LogoProps {
  tone?: "light" | "dark";
  className?: string;
}

/** Verdant wordmark — inverts on dark surfaces. */
export function Logo({ tone = "light", className = "" }: LogoProps) {
  const onDark = tone === "dark";
  return (
    <span className={`inline-flex select-none items-center gap-2.5 ${className}`}>
      <svg width="34" height="34" viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="9" fill={onDark ? "#faf7f0" : "#1b4332"} />
        <path
          d="M10 22C10 13.5 15 8.5 23 8c.8 8.5-3.5 14-13 14"
          stroke={onDark ? "#1b4332" : "#b7e4c7"}
          strokeWidth="2.4"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M12.5 20.5c3.2-1.2 6-4 7.8-8.3"
          stroke={onDark ? "#40916c" : "#74c69d"}
          strokeWidth="1.6"
          fill="none"
          strokeLinecap="round"
        />
      </svg>
      <span
        className="font-display text-[1.4rem] font-medium tracking-tight"
        style={{ color: onDark ? "#faf7f0" : "#0b1d14" }}
      >
        Verdant
      </span>
    </span>
  );
}
