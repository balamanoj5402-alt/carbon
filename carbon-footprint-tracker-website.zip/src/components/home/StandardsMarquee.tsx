import { Leaf } from "lucide-react";
import { PARTNERS } from "@/data/site";

export function StandardsMarquee() {
  const items = [...PARTNERS, ...PARTNERS];
  return (
    <section className="overflow-hidden bg-forest-950 py-7" aria-label="Standards and data sources">
      <div className="marquee-paused relative flex items-center">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-32 bg-gradient-to-r from-forest-950 to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-32 bg-gradient-to-l from-forest-950 to-transparent" />
        <div className="animate-marquee flex shrink-0 items-center gap-10 pr-10">
          {items.map((name, i) => (
            <span key={`${name}-${i}`} className="flex shrink-0 items-center gap-10">
              <span className="whitespace-nowrap font-display text-xl font-light italic text-cream/60 transition-colors duration-300 hover:text-cream">
                {name}
              </span>
              <Leaf className="h-3.5 w-3.5 shrink-0 text-sage-400/50" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
