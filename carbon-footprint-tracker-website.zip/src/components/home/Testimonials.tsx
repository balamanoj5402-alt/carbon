import { Star } from "lucide-react";
import { TESTIMONIALS } from "@/data/site";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function Testimonials() {
  return (
    <section className="bg-cream py-24 lg:py-32" aria-labelledby="testimonials-title">
      <div className="container-x">
        <SectionHeading
          eyebrow="Member stories"
          title={
            <>
              People don't change diets overnight. <em className="font-normal italic text-forest-700">They change numbers.</em>
            </>
          }
          description="Tens of thousands of members use Verdant every month. Here is what three of them told us about the first ninety days."
          align="center"
          className="mx-auto items-center"
        />

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.1}>
              <figure className="group flex h-full flex-col rounded-2xl border border-line bg-white/70 p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-sage-300 hover:shadow-lift">
                <div className="flex gap-1" aria-label="Rated 5 out of 5">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} className="h-4 w-4 fill-forest-600 text-forest-600" />
                  ))}
                </div>
                <blockquote className="mt-5 flex-1 text-[15px] leading-relaxed text-ink/85">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-7 flex items-center gap-3.5 border-t border-line pt-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-forest-800/10 text-sm font-semibold text-forest-800">
                    {t.initials}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-forest-950">{t.name}</p>
                    <p className="text-xs text-mist">
                      {t.role} · {t.location}
                    </p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
