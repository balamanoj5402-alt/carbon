import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowDown, ArrowRight, Leaf } from "lucide-react";
import heroImage from "@/assets/images/hero-forest.jpg";
import { DashboardPreview } from "./DashboardPreview";

const ease = [0.22, 1, 0.36, 1] as const;

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-forest-950">
      {/* Background image + overlays */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover opacity-55"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-forest-950/95 via-forest-950/70 to-forest-950/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-transparent to-forest-950/40" style={{ maskImage: "linear-gradient(to top, black 0%, transparent 24%)" }} />
      </div>

      <div className="container-x relative grid items-center gap-16 pb-32 pt-36 sm:pt-40 lg:min-h-screen lg:grid-cols-[1.05fr_0.95fr] lg:gap-12 lg:pb-40 lg:pt-32">
        {/* Copy */}
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease }}
            className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-xs font-medium tracking-wide text-sage-200 backdrop-blur"
          >
            <Leaf className="h-3.5 w-3.5" />
            The carbon intelligence platform
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.12, ease }}
            className="mt-7 text-[2.9rem] font-light leading-[1.06] tracking-[-0.015em] text-cream sm:text-6xl lg:text-[4.4rem]"
          >
            Know your footprint.
            <br />
            <em className="font-normal italic text-sage-300">Grow your impact.</em>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.24, ease }}
            className="mt-6 max-w-xl text-base leading-relaxed text-cream/75 sm:text-lg"
          >
            Verdant turns twenty everyday answers about your travel, home energy,
            food and waste into a clear, science-backed carbon picture — then
            builds the plan that bends it downward, month after month.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.36, ease }}
            className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center"
          >
            <Link
              to="/calculator"
              className="btn group bg-cream px-7 py-3.5 text-sm font-semibold text-forest-950 hover:-translate-y-0.5 hover:bg-sage-200 hover:shadow-soft"
            >
              Start tracking — it's free
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
            <Link
              to="/about"
              className="btn border border-white/30 px-7 py-3.5 text-sm text-cream hover:-translate-y-0.5 hover:bg-white/10"
            >
              Learn more
              <ArrowDown className="h-4 w-4" />
            </Link>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="mt-8 text-xs tracking-wide text-cream/50"
          >
            No account needed for your first estimate · Data never sold ·
            Cancel anytime
          </motion.p>
        </div>

        {/* Dashboard preview */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.1, delay: 0.4, ease }}
          className="flex justify-center lg:justify-end"
        >
          <DashboardPreview />
        </motion.div>
      </div>
    </section>
  );
}
