import { useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, ArrowUpRight, TrendingDown } from "lucide-react";
import { CATEGORIES, GOALS, deltaPct, monthlyHistory } from "@/data/dashboard";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { smoothLinePath } from "@/utils/path";
import { fmtTonnes } from "@/utils/format";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "goals", label: "Goals" },
  { id: "history", label: "History" },
] as const;

type TabId = (typeof TABS)[number]["id"];

const W = 560;
const H = 190;
const PAD_X = 28;
const PAD_Y = 26;

function Chart() {
  const totals = monthlyHistory.map((m) => m.total);
  const max = Math.max(...totals);
  const min = Math.min(...totals);
  const points = monthlyHistory.map((m, i) => ({
    x: PAD_X + (i / (monthlyHistory.length - 1)) * (W - PAD_X * 2),
    y: PAD_Y + (1 - (m.total - min) / (max - min)) * (H - PAD_Y * 2 - 26),
  }));
  const line = smoothLinePath(points);
  const area = `${line} L ${points[points.length - 1].x} ${H - 20} L ${points[0].x} ${H - 20} Z`;

  return (
    <div className="rounded-2xl border border-line bg-cream p-5">
      <div className="flex items-baseline justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">Monthly footprint</p>
          <p className="mt-1.5 font-display text-3xl font-light text-forest-950">
            <span className="tnum">1.18</span> <span className="text-sm text-mist">t CO₂e</span>
          </p>
        </div>
        <span className="inline-flex items-center gap-1 rounded-full bg-forest-800/5 px-2.5 py-1 text-xs font-semibold text-forest-800">
          <TrendingDown className="h-3.5 w-3.5" />
          12.2%
        </span>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="mt-4 h-[190px] w-full" role="img" aria-label="Twelve month footprint trend">
        <defs>
          <linearGradient id="platform-area" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#95d5b2" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#95d5b2" stopOpacity="0.05" />
          </linearGradient>
          <clipPath id="chart-clip">
            <motion.rect
              x="0"
              y="0"
              height={H}
              initial={{ width: 0 }}
              whileInView={{ width: W }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
            />
          </clipPath>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line
            key={f}
            x1={PAD_X}
            x2={W - PAD_X}
            y1={PAD_Y + f * (H - PAD_Y * 2 - 26)}
            y2={PAD_Y + f * (H - PAD_Y * 2 - 26)}
            stroke="#e7e0cf"
            strokeDasharray="3 6"
          />
        ))}
        <g clipPath="url(#chart-clip)">
          <path d={area} fill="url(#platform-area)" />
          <motion.path
            d={line}
            fill="none"
            stroke="#1b4332"
            strokeWidth="2.5"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1] }}
          />
          <circle cx={points[points.length - 1].x} cy={points[points.length - 1].y} r="5" fill="#1b4332" stroke="#faf7f0" strokeWidth="2.5" />
        </g>
        {monthlyHistory.map((m, i) =>
          i % 2 === 0 ? (
            <text key={m.id} x={points[i].x} y={H - 4} textAnchor="middle" fontSize="10" fill="#68766d">
              {m.short}
            </text>
          ) : null
        )}
      </svg>
    </div>
  );
}

function CategoryPanel() {
  const current = monthlyHistory[monthlyHistory.length - 1];
  return (
    <div className="flex h-full flex-col rounded-2xl border border-line bg-cream p-5">
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">July breakdown</p>
      <div className="mt-4 flex-1 space-y-4">
        {CATEGORIES.map((c, i) => {
          const v = current[c.key as "transport" | "energy" | "food" | "waste"];
          const pct = (v / current.total) * 100;
          return (
            <div key={c.key}>
              <div className="flex items-baseline justify-between text-sm">
                <span className="flex items-center gap-2 text-ink/80">
                  <c.icon className="h-4 w-4" style={{ color: c.color }} strokeWidth={1.8} />
                  {c.label}
                </span>
                <span className="tnum font-medium text-forest-900">
                  {fmtTonnes(v)} t · {Math.round(pct)}%
                </span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-cream-deep">
                <motion.div
                  className="h-full origin-left rounded-full"
                  style={{ background: c.color }}
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: pct / 100 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, delay: 0.3 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-5 rounded-xl bg-sage-100 p-4 text-[13px] leading-snug text-forest-900">
        <span className="font-semibold">Smart insight:</span> transport is now
        your largest category. Swapping two car trips a week for rail could save
        ~0.18 t this month.
      </div>
    </div>
  );
}

function OverviewTab() {
  return (
    <div className="grid gap-4 md:grid-cols-5">
      <div className="md:col-span-3">
        <Chart />
      </div>
      <div className="md:col-span-2">
        <CategoryPanel />
      </div>
    </div>
  );
}

function GoalsTab() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {GOALS.slice(0, 4).map((g, i) => (
        <div key={g.id} className="rounded-2xl border border-line bg-cream p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-sage-100 text-forest-700">
                <g.icon className="h-5 w-5" strokeWidth={1.8} />
              </span>
              <div>
                <p className="text-sm font-semibold text-forest-950">{g.title}</p>
                <p className="text-xs text-mist">{g.detail}</p>
              </div>
            </div>
            <span
              className={`chip shrink-0 ${
                g.status === "At risk"
                  ? "border-[#c87f4f]/30 bg-[#c87f4f]/10 text-[#a55f2e]"
                  : "border-forest-600/25 bg-forest-600/10 text-forest-700"
              }`}
            >
              {g.status}
            </span>
          </div>
          <div className="mt-5">
            <div className="flex items-baseline justify-between text-sm">
              <span className="tnum font-medium text-forest-900">
                {g.current} <span className="text-xs text-mist">{g.unit}</span>
              </span>
              <span className="text-xs text-mist">
                target {g.target} {g.unit}
              </span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-cream-deep">
              <motion.div
                className="h-full origin-left rounded-full bg-forest-700"
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: g.progress / 100 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: 0.2 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              />
            </div>
            <p className="mt-2 text-xs text-mist">
              {g.progress}% complete · due {g.deadline}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

function HistoryTab() {
  const rows = monthlyHistory.slice(-6);
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-cream">
      <div className="hidden grid-cols-[1.2fr_1fr_1fr_2fr] gap-4 border-b border-line px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-mist sm:grid">
        <span>Month</span>
        <span>Total</span>
        <span>Change</span>
        <span>Breakdown</span>
      </div>
      {rows.map((m, i) => {
        const prev = monthlyHistory[monthlyHistory.length - 6 + i - 1];
        const d = prev ? deltaPct(m.total, prev.total) : 0;
        return (
          <motion.div
            key={m.id}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-2 items-center gap-4 border-b border-line/60 px-5 py-3.5 transition-colors last:border-0 hover:bg-sage-100/50 sm:grid-cols-[1.2fr_1fr_1fr_2fr]"
          >
            <span className="text-sm font-medium text-forest-950">{m.label}</span>
            <span className="tnum text-sm text-ink/80">{fmtTonnes(m.total)} t</span>
            <span>
              {i === 0 ? (
                <span className="text-xs text-mist">—</span>
              ) : (
                <span
                  className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                    d <= 0 ? "bg-forest-600/10 text-forest-700" : "bg-[#c87f4f]/10 text-[#a55f2e]"
                  }`}
                >
                  <TrendingDown className={`h-3 w-3 ${d > 0 ? "rotate-180" : ""}`} />
                  {Math.abs(d).toFixed(1)}%
                </span>
              )}
            </span>
            <div className="col-span-2 h-2 overflow-hidden rounded-full bg-cream-deep sm:col-span-1">
              <div className="flex h-full">
                {CATEGORIES.map((c) => (
                  <span
                    key={c.key}
                    className="h-full"
                    style={{ width: `${(m[c.key as "transport" | "energy" | "food" | "waste"] / m.total) * 100}%`, background: c.color }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

export function PlatformPreview() {
  const [tab, setTab] = useState<TabId>("overview");

  return (
    <section className="bg-cream-deep/60 py-24 lg:py-32" aria-labelledby="preview-title">
      <div className="container-x">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Inside the dashboard"
            title={
              <>
                One clear view of <em className="font-normal italic text-forest-700">your carbon</em>
              </>
            }
            description="Your numbers, your categories, your plan — organised so the next right step is always obvious. This is a live preview with sample member data."
          />
          <Reveal delay={0.15}>
            <Link to="/dashboard" className="btn-outline group shrink-0">
              Open the dashboard
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <div className="mt-12">
            {/* Browser chrome */}
            <div className="rounded-3xl border border-line bg-white/60 p-2 shadow-soft backdrop-blur">
              <div className="flex items-center gap-3 rounded-t-2xl px-4 py-3">
                <span className="flex gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-[#e3b9a8]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#e8ddb5]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#bcd9c2]" />
                </span>
                <span className="ml-2 flex-1">
                  <span className="inline-flex items-center gap-2 rounded-full border border-line bg-cream px-4 py-1.5 text-xs text-mist">
                    <span className="h-1.5 w-1.5 rounded-full bg-forest-600" />
                    verdant.app/dashboard
                  </span>
                </span>
              </div>

              <div className="rounded-b-2xl rounded-t-xl border border-line bg-cream/80 p-4 sm:p-6">
                {/* Tabs */}
                <div className="mb-6 flex flex-wrap items-center gap-2" role="tablist" aria-label="Dashboard preview sections">
                  {TABS.map((t) => {
                    const active = tab === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        onClick={() => setTab(t.id)}
                        className={`relative rounded-full px-5 py-2.5 text-sm transition-colors duration-300 ${
                          active ? "text-cream" : "text-mist hover:text-forest-900"
                        }`}
                      >
                        {active && (
                          <motion.span
                            layoutId="preview-tab"
                            className="absolute inset-0 rounded-full bg-forest-800"
                            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                          />
                        )}
                        <span className="relative">{t.label}</span>
                      </button>
                    );
                  })}
                  <Link
                    to="/dashboard"
                    className="group ml-auto inline-flex items-center gap-1.5 text-sm font-medium text-forest-700 hover:text-forest-900"
                  >
                    Full dashboard
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </Link>
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={tab}
                    role="tabpanel"
                    initial={{ opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  >
                    {tab === "overview" && <OverviewTab />}
                    {tab === "goals" && <GoalsTab />}
                    {tab === "history" && <HistoryTab />}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
