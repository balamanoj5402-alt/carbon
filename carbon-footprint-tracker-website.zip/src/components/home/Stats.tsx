import { IMPACT_STATS } from "@/data/site";
import { Counter } from "@/components/ui/Counter";
import { Reveal } from "@/components/ui/Reveal";

export function Stats() {
  return (
    <section className="border-b border-line bg-cream" aria-label="Impact statistics">
      <div className="container-x grid grid-cols-2 gap-x-8 gap-y-10 py-14 lg:grid-cols-4 lg:py-16">
        {IMPACT_STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.08}>
            <div className="group lg:border-l lg:border-line lg:pl-8 lg:first:border-0 lg:first:pl-0">
              <p className="font-display text-4xl font-light tracking-tight text-forest-950 sm:text-5xl">
                <Counter value={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-2.5 max-w-[14rem] text-sm leading-snug text-mist">{s.label}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
