import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import canopyImage from "@/assets/images/canopy.jpg";
import { Reveal } from "@/components/ui/Reveal";

export function CtaBand() {
  return (
    <section className="relative overflow-hidden bg-forest-950" aria-label="Call to action">
      <img
        src={canopyImage}
        alt=""
        aria-hidden="true"
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover opacity-30"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-forest-950/85 via-forest-950/70 to-forest-950/90" />

      <div className="container-x relative flex flex-col items-center py-24 text-center lg:py-32">
        <Reveal>
          <span className="inline-flex items-center gap-2.5 text-[11px] font-semibold uppercase tracking-[0.26em] text-sage-300">
            <span className="h-px w-8 bg-sage-300/60" />
            Your move
            <span className="h-px w-8 bg-sage-300/60" />
          </span>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="mt-5 max-w-3xl text-4xl font-light leading-[1.08] tracking-[-0.015em] text-cream sm:text-5xl">
            Small steps. <em className="font-normal italic text-sage-300">Measured impact.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.16}>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-cream/70">
            Your first estimate takes five minutes and no account. Your first
            tonne of reduction usually takes less than a season.
          </p>
        </Reveal>
        <Reveal delay={0.24}>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Link
              to="/calculator"
              className="btn group bg-cream px-8 py-3.5 text-sm font-semibold text-forest-950 hover:-translate-y-0.5 hover:bg-sage-200 hover:shadow-soft"
            >
              Start tracking — it's free
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
            <Link
              to="/dashboard"
              className="btn border border-white/30 px-8 py-3.5 text-sm text-cream hover:-translate-y-0.5 hover:bg-white/10"
            >
              Explore the dashboard
            </Link>
          </div>
        </Reveal>
        <Reveal delay={0.32}>
          <p className="mt-8 text-xs tracking-wide text-cream/50">
            128,400+ members · 41,600 t tracked · 23% average reduction
          </p>
        </Reveal>
      </div>
    </section>
  );
}
