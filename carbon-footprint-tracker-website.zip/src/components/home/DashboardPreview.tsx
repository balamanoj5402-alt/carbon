import { motion } from "framer-motion";
import { Target, TrendingDown } from "lucide-react";
import { monthlyHistory, CATEGORIES, currentMonth } from "@/data/dashboard";
import { smoothLinePath } from "@/utils/path";

const W = 300;
const H = 92;
const PAD_X = 6;
const PAD_Y = 10;

function useSparkPoints() {
  const totals = monthlyHistory.map((m) => m.total);
  const max = Math.max(...totals);
  const min = Math.min(...totals);
  return monthlyHistory.map((m, i) => ({
    x: PAD_X + (i / (monthlyHistory.length - 1)) * (W - PAD_X * 2),
    y: PAD_Y + (1 - (m.total - min) / (max - min)) * (H - PAD_Y * 2),
  }));
}

const RING_R = 30;
const RING_C = 2 * Math.PI * RING_R;
const GOAL_PCT = 0.64;

function CategoryRow({
  color,
  label,
  value,
  pct,
  index,
}: {
  color: string;
  label: string;
  value: string;
  pct: number;
  index: number;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between text-[13px]">
        <span className="flex items-center gap-2 text-ink/80">
          <span className="h-2 w-2 rounded-full" style={{ background: color }} />
          {label}
        </span>
        <span className="tnum font-medium text-forest-900">{value}</span>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-cream-deep">
        <motion.div
          className="h-full origin-left rounded-full"
          style={{ background: color }}
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: pct / 100 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.5 + index * 0.09, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>
    </div>
  );
}

export function DashboardPreview() {
  const points = useSparkPoints();
  const line = smoothLinePath(points);
  const area = `${line} L ${points[points.length - 1].x} ${H} L ${points[0].x} ${H} Z`;
  const categories = [
    { ...CATEGORIES[0], kg: currentMonth.transport * 1000, pct: (currentMonth.transport / currentMonth.total) * 100 },
    { ...CATEGORIES[1], kg: currentMonth.energy * 1000, pct: (currentMonth.energy / currentMonth.total) * 100 },
    { ...CATEGORIES[2], kg: currentMonth.food * 1000, pct: (currentMonth.food / currentMonth.total) * 100 },
    { ...CATEGORIES[3], kg: currentMonth.waste * 1000, pct: (currentMonth.waste / currentMonth.total) * 100 },
  ];

  return (
    <div className="relative">
      {/* Glow behind card */}
      <div
        aria-hidden="true"
        className="absolute -inset-10 rounded-[3rem] bg-gradient-to-br from-forest-500/25 via-sage-300/20 to-transparent blur-2xl"
      />

      <div className="relative w-full max-w-md rounded-[1.75rem] border border-line bg-cream/95 p-6 shadow-soft backdrop-blur sm:p-7">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-mist">Your footprint</p>
            <p className="mt-1 text-sm text-ink/70">July 2026</p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-sage-100 px-2.5 py-1 text-[11px] font-medium text-forest-800">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-forest-500 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-forest-600" />
            </span>
            Synced
          </span>
        </div>

        {/* Total */}
        <div className="mt-5 flex items-end gap-3">
          <span className="tnum font-display text-[3.4rem] font-light leading-none tracking-tight text-forest-950">
            1.18
          </span>
          <span className="pb-1.5 text-sm text-mist">t CO₂e</span>
          <span className="mb-1 ml-auto inline-flex items-center gap-1 rounded-full bg-forest-800/5 px-2.5 py-1 text-xs font-semibold text-forest-800">
            <TrendingDown className="h-3.5 w-3.5" />
            12.2%
          </span>
        </div>

        {/* Sparkline */}
        <div className="relative mt-5 overflow-hidden">
          <svg viewBox={`0 0 ${W} ${H}`} className="h-[92px] w-full" role="img" aria-label="Monthly footprint trend, decreasing from 2.05 to 1.18 tonnes">
            <defs>
              <linearGradient id="preview-area" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#95d5b2" stopOpacity="0.55" />
                <stop offset="100%" stopColor="#95d5b2" stopOpacity="0.05" />
              </linearGradient>
            </defs>
            <path d={area} fill="url(#preview-area)" />
            <motion.path
              d={line}
              fill="none"
              stroke="#1b4332"
              strokeWidth="2"
              strokeLinecap="round"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
            />
            <motion.circle
              cx={points[points.length - 1].x}
              cy={points[points.length - 1].y}
              r="4"
              fill="#1b4332"
              stroke="#faf7f0"
              strokeWidth="2"
              initial={{ scale: 0, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 1.5, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            />
          </svg>
        </div>

        {/* Goal row */}
        <div className="mt-6 flex items-center gap-4 rounded-2xl border border-line bg-white/60 p-4">
          <svg width="68" height="68" viewBox="0 0 68 68" className="shrink-0 -rotate-90" role="img" aria-label="74 percent of monthly goal achieved">
            <circle cx="34" cy="34" r={RING_R} fill="none" stroke="#e7e0cf" strokeWidth="5" />
            <motion.circle
              cx="34"
              cy="34"
              r={RING_R}
              fill="none"
              stroke="#2d6a4f"
              strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray={RING_C}
              initial={{ strokeDashoffset: RING_C }}
              whileInView={{ strokeDashoffset: RING_C * (1 - GOAL_PCT) }}
              viewport={{ once: true }}
              transition={{ duration: 1.4, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            />
          </svg>
          <div>
            <p className="text-sm font-semibold text-forest-900">64% to goal</p>
            <p className="mt-0.5 text-[13px] leading-snug text-mist">
              Just <span className="tnum font-medium text-forest-800">0.08 t</span> from your 1.10 t monthly target
            </p>
          </div>
        </div>

        {/* Categories */}
        <div className="mt-5 space-y-3.5">
          {categories.map((c, i) => (
            <CategoryRow
              key={c.key}
              color={c.color}
              label={c.label}
              value={`${Math.round(c.kg)} kg`}
              pct={c.pct}
              index={i}
            />
          ))}
        </div>
      </div>

      {/* Floating chips */}
      <motion.div
        className="animate-float-y absolute -right-4 -top-5 hidden items-center gap-2 rounded-full border border-line bg-cream px-4 py-2.5 text-xs font-medium text-forest-900 shadow-card sm:flex"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      >
        <Target className="h-3.5 w-3.5 text-forest-700" />
        Goal in reach — 0.08 t to go
      </motion.div>

      <motion.div
        className="animate-float-y-slow absolute -bottom-5 -left-5 hidden items-center gap-2 rounded-full bg-forest-900 px-4 py-2.5 text-xs font-medium text-cream shadow-card md:flex"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.3, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      >
        <TrendingDown className="h-3.5 w-3.5 text-sage-300" />
        −1.4 t since January
      </motion.div>
    </div>
  );
}
