import { ArrowUpRight } from "lucide-react";
import { FEATURES } from "@/data/site";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function Features() {
  return (
    <section className="bg-cream py-24 lg:py-32" aria-labelledby="features-title">
      <div className="container-x">
        <SectionHeading
          eyebrow="The platform"
          title={
            <>
              Everything you need to <em className="font-normal italic text-forest-700">bend the curve</em>
            </>
          }
          description="Not another guilt trip. A measurement engine, a thinking partner and a progress tracker — built on open, audited data."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={(i % 3) * 0.09}>
              <article className="group flex h-full flex-col rounded-2xl border border-line bg-white/70 p-7 transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:border-sage-300 hover:shadow-lift">
                <div className="flex items-start justify-between">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-sage-100 text-forest-700 transition-colors duration-300 group-hover:bg-forest-800 group-hover:text-cream">
                    <f.icon className="h-5 w-5" strokeWidth={1.8} />
                  </span>
                  <ArrowUpRight className="h-4 w-4 text-mist opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100" />
                </div>
                <h3 className="mt-6 text-lg font-medium tracking-tight text-forest-950">{f.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-mist">{f.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
