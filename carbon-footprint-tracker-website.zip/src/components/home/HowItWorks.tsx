import { STEPS } from "@/data/site";
import { Reveal } from "@/components/ui/Reveal";

export function HowItWorks() {
  return (
    <section className="relative overflow-hidden bg-forest-950 py-24 text-cream lg:py-32" aria-labelledby="how-title">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-40 -top-40 h-[30rem] w-[30rem] rounded-full bg-forest-600/15 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-48 -left-32 h-[28rem] w-[28rem] rounded-full bg-sage-400/10 blur-3xl"
      />

      <div className="container-x relative">
        <div className="flex flex-col gap-4">
          <Reveal>
            <span className="inline-flex items-center gap-2.5 text-[11px] font-semibold uppercase tracking-[0.26em] text-sage-300">
              <span className="h-px w-8 bg-sage-300/60" />
              How it works
            </span>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 id="how-title" className="max-w-2xl text-3xl font-light leading-[1.12] tracking-[-0.01em] sm:text-4xl lg:text-[2.75rem]">
              From <em className="font-normal italic text-sage-300">curious</em> to <em className="font-normal italic text-sage-300">carbon-literate</em> in one evening
            </h2>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-10 md:grid-cols-3 md:gap-8">
          {STEPS.map((step, i) => (
            <Reveal key={step.number} delay={i * 0.12}>
              <article className="relative">
                {i < STEPS.length - 1 && (
                  <span
                    aria-hidden="true"
                    className="absolute left-14 top-8 hidden h-px w-[calc(100%-3rem)] bg-gradient-to-r from-white/25 to-transparent md:block"
                  />
                )}
                <span className="relative inline-flex h-16 w-16 items-center justify-center rounded-2xl border border-white/15 bg-white/5">
                  <step.icon className="h-6 w-6 text-sage-300" strokeWidth={1.6} />
                  <span className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-cream text-[11px] font-semibold text-forest-950">
                    {i + 1}
                  </span>
                </span>
                <h3 className="mt-6 text-xl font-medium tracking-tight">{step.title}</h3>
                <p className="mt-3 max-w-sm text-sm leading-relaxed text-cream/65">{step.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
