import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { CATEGORIES, monthKey, monthlyHistory, type MonthRecord } from "@/data/dashboard";
import { SliderRow } from "@/components/calculator/controls";
import { fmtTonnes } from "@/utils/format";

interface AddEntryModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (record: MonthRecord, monthLabel: string, isNew: boolean) => void;
}

const NEXT_MONTH = "Aug 2026";
const MONTH_OPTIONS = [...monthlyHistory.map((m) => m.label), NEXT_MONTH];

interface FormState {
  month: string;
  total: number;
  cats: { transport: number; energy: number; food: number; waste: number };
}

function initialForm(): FormState {
  const last = monthlyHistory[monthlyHistory.length - 1];
  return {
    month: NEXT_MONTH,
    total: 1.1,
    cats: {
      transport: last.transport,
      energy: last.energy,
      food: last.food,
      waste: last.waste,
    },
  };
}

export function AddEntryModal({ open, onClose, onSave }: AddEntryModalProps) {
  const [form, setForm] = useState<FormState>(initialForm);
  const [error, setError] = useState<string | null>(null);

  // Reset when opened
  useEffect(() => {
    if (open) {
      setForm(initialForm());
      setError(null);
    }
  }, [open]);

  // Escape + scroll lock
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  const pickMonth = (month: string) => {
    const existing = monthlyHistory.find((m) => m.label === month);
    setForm((f) => ({
      month,
      total: existing ? existing.total : 1.1,
      cats: existing
        ? { transport: existing.transport, energy: existing.energy, food: existing.food, waste: existing.waste }
        : f.cats,
    }));
    setError(null);
  };

  const sum = form.cats.transport + form.cats.energy + form.cats.food + form.cats.waste;

  const handleSave = () => {
    if (form.total < 0.3 || form.total > 8) {
      setError("Total should be between 0.3 and 8.0 t for a single month.");
      return;
    }
    if (sum <= 0) {
      setError("At least one category needs a value above zero.");
      return;
    }
    const factor = form.total / sum;
    const scaled = {
      transport: Math.round(form.cats.transport * factor * 100) / 100,
      energy: Math.round(form.cats.energy * factor * 100) / 100,
      food: Math.round(form.cats.food * factor * 100) / 100,
      waste: Math.round(form.cats.waste * factor * 100) / 100,
    };
    // Fix rounding drift on the largest category
    const drift = Math.round((form.total - (scaled.transport + scaled.energy + scaled.food + scaled.waste)) * 100) / 100;
    if (drift !== 0) {
      const largest = (Object.keys(scaled) as Array<keyof typeof scaled>).sort(
        (a, b) => scaled[b] - scaled[a]
      )[0];
      scaled[largest] = Math.round((scaled[largest] + drift) * 100) / 100;
    }
    const isNew = !monthlyHistory.some((m) => m.label === form.month);
    const short = form.month.split(" ")[0];
    const record: MonthRecord = {
      id: `entry-${monthKey(form.month)}`,
      label: form.month,
      short,
      ...scaled,
      total: scaled.transport + scaled.energy + scaled.food + scaled.waste,
    };
    onSave(record, form.month, isNew);
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[95] flex items-end justify-center p-4 sm:items-center">
          <motion.div
            className="absolute inset-0 bg-forest-950/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            aria-hidden="true"
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="entry-modal-title"
            className="relative max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-line bg-cream p-6 shadow-soft sm:p-8"
            initial={{ opacity: 0, y: 48, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 32, scale: 0.98 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 id="entry-modal-title" className="text-xl font-medium tracking-tight text-forest-950">
                  Add a monthly entry
                </h3>
                <p className="mt-1 text-sm text-mist">
                  Edit a past month or log the new one. Categories scale to your total.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close dialog"
                className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line text-mist transition-colors hover:bg-forest-800/5 hover:text-forest-900"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-6 space-y-6">
              <div>
                <label htmlFor="entry-month" className="text-sm font-medium text-ink/85">
                  Month
                </label>
                <select
                  id="entry-month"
                  value={form.month}
                  onChange={(e) => pickMonth(e.target.value)}
                  className="input-field mt-2"
                >
                  {MONTH_OPTIONS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                      {m === NEXT_MONTH ? " (new)" : ""}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="entry-total" className="text-sm font-medium text-ink/85">
                  Total footprint (t CO₂e)
                </label>
                <input
                  id="entry-total"
                  type="number"
                  min={0.3}
                  max={8}
                  step={0.01}
                  value={form.total}
                  onChange={(e) => {
                    setForm((f) => ({ ...f, total: Number(e.target.value) }));
                    setError(null);
                  }}
                  className="input-field mt-2 tnum"
                />
              </div>

              <div className="space-y-5 rounded-2xl border border-line bg-white/60 p-5">
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">
                  Category split
                </p>
                {CATEGORIES.map((c) => (
                  <SliderRow
                    key={c.key}
                    id={`entry-${c.key}`}
                    label={c.label}
                    value={form.cats[c.key as "transport" | "energy" | "food" | "waste"]}
                    min={0}
                    max={1.5}
                    step={0.01}
                    unit="t"
                    onChange={(v) => {
                      setForm((f) => ({ ...f, cats: { ...f.cats, [c.key]: v } }));
                      setError(null);
                    }}
                  />
                ))}
                <p className="flex items-center justify-between rounded-xl bg-sage-100 px-3.5 py-2.5 text-xs">
                  <span className="text-forest-900">Allocated</span>
                  <span className={`tnum font-semibold ${Math.abs(sum - form.total) > 0.05 ? "text-[#a55f2e]" : "text-forest-900"}`}>
                    {fmtTonnes(sum)} / {fmtTonnes(form.total)} t
                    {Math.abs(sum - form.total) > 0.05 ? " — scaled on save" : ""}
                  </span>
                </p>
              </div>

              {error && (
                <p role="alert" className="rounded-xl border border-[#c87f4f]/30 bg-[#c87f4f]/10 px-4 py-3 text-sm text-[#a55f2e]">
                  {error}
                </p>
              )}

              <div className="flex flex-col gap-3 sm:flex-row">
                <button type="button" onClick={onClose} className="btn-outline flex-1 py-3">
                  Cancel
                </button>
                <button type="button" onClick={handleSave} className="btn-primary group flex-1 py-3">
                  <Check className="h-4 w-4" />
                  Save entry
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
