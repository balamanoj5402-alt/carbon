import { Plus } from "lucide-react";
import { CATEGORIES, deltaPct, type MonthRecord } from "@/data/dashboard";
import { DeltaChip } from "./DeltaChip";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { fmtTonnes } from "@/utils/format";

interface HistoryTableProps {
  records: MonthRecord[];
  onAdd: () => void;
}

export function HistoryTable({ records, onAdd }: HistoryTableProps) {
  return (
    <section aria-labelledby="history-title">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <SectionHeading
          eyebrow="History"
          title={
            <>
              Month by <em className="font-normal italic text-forest-700">month</em>
            </>
          }
          description="Every entry with its category split. Scroll, hover and compare — or add one of your own."
        />
        <Reveal delay={0.12}>
          <button type="button" onClick={onAdd} className="btn-outline shrink-0">
            <Plus className="h-4 w-4" />
            Add entry
          </button>
        </Reveal>
      </div>

      <Reveal delay={0.1}>
        <div className="mt-8 overflow-hidden rounded-2xl border border-line bg-white/70 shadow-card">
          <div className="max-h-[430px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-10 bg-cream/95 text-[11px] uppercase tracking-[0.14em] text-mist backdrop-blur">
                <tr>
                  <th scope="col" className="px-5 py-3.5 text-left font-semibold">Month</th>
                  <th scope="col" className="px-5 py-3.5 text-right font-semibold">Total</th>
                  <th scope="col" className="hidden px-5 py-3.5 text-right font-semibold sm:table-cell">Change</th>
                  <th scope="col" className="w-[28%] px-5 py-3.5 text-left font-semibold">Breakdown</th>
                </tr>
              </thead>
              <tbody>
                {records.map((m, i) => {
                  const prev = records[i - 1];
                  const d = prev ? deltaPct(m.total, prev.total) : null;
                  return (
                    <tr
                      key={m.id}
                      className="border-t border-line/60 transition-colors duration-200 hover:bg-sage-100/40"
                    >
                      <td className="px-5 py-3.5 font-medium text-forest-950">{m.label}</td>
                      <td className="tnum px-5 py-3.5 text-right text-ink/85">{fmtTonnes(m.total)} t</td>
                      <td className="hidden px-5 py-3.5 text-right sm:table-cell">
                        {d === null ? <span className="text-xs text-mist">—</span> : <DeltaChip pct={d} suffix="" />}
                      </td>
                      <td className="px-5 py-3.5">
                        <div
                          className="flex h-2 overflow-hidden rounded-full bg-cream-deep"
                          title={`Transport ${fmtTonnes(m.transport)} t · Energy ${fmtTonnes(m.energy)} t · Food ${fmtTonnes(m.food)} t · Waste ${fmtTonnes(m.waste)} t`}
                        >
                          {CATEGORIES.map((c) => (
                            <span
                              key={c.key}
                              className="h-full transition-all duration-300"
                              style={{
                                width: `${(m[c.key as "transport" | "energy" | "food" | "waste"] / m.total) * 100}%`,
                                background: c.color,
                              }}
                            />
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
