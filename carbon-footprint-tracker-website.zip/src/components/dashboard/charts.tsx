import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CATEGORIES, type MonthRecord } from "@/data/dashboard";
import { fmtTonnes } from "@/utils/format";

/* eslint-disable @typescript-eslint/no-explicit-any */

function StackedTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((s: number, p: any) => s + (Number(p.value) || 0), 0);
  return (
    <div className="min-w-40 rounded-xl border border-line bg-cream/95 px-4 py-3 shadow-card backdrop-blur">
      <p className="text-xs font-semibold text-forest-950">{label}</p>
      <p className="tnum mt-1.5 text-[13px] font-semibold text-forest-900">{fmtTonnes(total)} t total</p>
      <div className="mt-2 space-y-1 border-t border-line pt-2">
        {payload.map((p: any) => (
          <p key={String(p.dataKey)} className="flex items-center gap-2 text-[11px] text-mist">
            <span className="h-2 w-2 rounded-full" style={{ background: p.color ?? p.fill }} />
            <span className="flex-1">{p.name}</span>
            <span className="tnum">{fmtTonnes(Number(p.value))} t</span>
          </p>
        ))}
      </div>
    </div>
  );
}

export function MonthlyAreaChart({ data }: { data: MonthRecord[] }) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: -12, bottom: 0 }}>
        <defs>
          {CATEGORIES.map((c) => (
            <linearGradient key={c.key} id={`grad-${c.key}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={c.color} stopOpacity={0.95} />
              <stop offset="100%" stopColor={c.color} stopOpacity={0.5} />
            </linearGradient>
          ))}
        </defs>
        <CartesianGrid strokeDasharray="3 6" stroke="#e7e0cf" vertical={false} />
        <XAxis
          dataKey="short"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "#68766d", fontSize: 11 }}
          dy={8}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fill: "#68766d", fontSize: 11 }}
          tickFormatter={(v: number) => v.toFixed(1)}
          width={48}
        />
        <Tooltip
          content={<StackedTooltip />}
          cursor={{ stroke: "#2d6a4f", strokeWidth: 1, strokeDasharray: "4 4" }}
        />
        {CATEGORIES.map((c) => (
          <Area
            key={c.key}
            type="monotone"
            dataKey={c.key}
            name={c.label}
            stackId="1"
            stroke={c.color}
            strokeWidth={1.5}
            fill={`url(#grad-${c.key})`}
            animationDuration={900}
            animationEasing="ease-out"
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
}

function DonutTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const p = payload[0];
  return (
    <div className="rounded-xl border border-line bg-cream/95 px-3.5 py-2.5 shadow-card backdrop-blur">
      <p className="flex items-center gap-2 text-[11px] text-mist">
        <span className="h-2 w-2 rounded-full" style={{ background: p.payload.color }} />
        {p.name}
      </p>
      <p className="tnum mt-1 text-[13px] font-semibold text-forest-900">{fmtTonnes(Number(p.value))} t</p>
    </div>
  );
}

export function CategoryDonut({ record }: { record: MonthRecord }) {
  const data = CATEGORIES.map((c) => ({
    key: c.key,
    label: c.label,
    color: c.color,
    value: Math.round(record[c.key as "transport" | "energy" | "food" | "waste"] * 100) / 100,
  }));

  return (
    <div className="relative">
      <ResponsiveContainer width="100%" height={250}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="label"
            innerRadius={68}
            outerRadius={94}
            paddingAngle={3}
            cornerRadius={5}
            strokeWidth={0}
            animationDuration={900}
            animationEasing="ease-out"
          >
            {data.map((d) => (
              <Cell key={d.key} fill={d.color} />
            ))}
          </Pie>
          <Tooltip content={<DonutTooltip />} />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center pt-1">
        <p className="tnum font-display text-4xl font-light text-forest-950">{fmtTonnes(record.total)}</p>
        <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-mist">t CO₂e</p>
      </div>
    </div>
  );
}
