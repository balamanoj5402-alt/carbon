import { motion } from "framer-motion";
import { GOALS } from "@/data/dashboard";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";

export function GoalsPanel() {
  return (
    <section aria-labelledby="goals-title">
      <SectionHeading
        eyebrow="Reduction goals"
        title={
          <>
            Targets that <em className="font-normal italic text-forest-700">move with you</em>
          </>
        }
        description="Goals recalibrate every month from your real data — honest, but never discouraging."
      />
      <div className="mt-10 grid gap-5 sm:grid-cols-2">
        {GOALS.map((g, i) => (
          <Reveal key={g.id} delay={(i % 2) * 0.08}>
            <article className="group flex h-full flex-col rounded-2xl border border-line bg-white/70 p-6 transition-all duration-500 hover:-translate-y-1 hover:border-sage-300 hover:shadow-lift">
              <div className="flex items-start justify-between gap-3">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-sage-100 text-forest-700 transition-colors duration-300 group-hover:bg-forest-800 group-hover:text-cream">
                  <g.icon className="h-5 w-5" strokeWidth={1.8} />
                </span>
                <span
                  className={`chip ${
                    g.status === "At risk"
                      ? "border-[#c87f4f]/30 bg-[#c87f4f]/10 text-[#a55f2e]"
                      : "border-forest-600/25 bg-forest-600/10 text-forest-700"
                  }`}
                >
                  {g.status}
                </span>
              </div>
              <h3 className="mt-5 text-base font-medium tracking-tight text-forest-950">{g.title}</h3>
              <p className="mt-1 text-xs text-mist">{g.detail}</p>

              <div className="mt-5">
                <div className="flex items-baseline justify-between text-[13px]">
                  <span className="tnum font-semibold text-forest-900">
                    {g.current} <span className="text-xs font-normal text-mist">{g.unit}</span>
                  </span>
                  <span className="text-xs text-mist">
                    target {g.target} {g.unit}
                  </span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-cream-deep">
                  <motion.div
                    className="h-full origin-left rounded-full bg-gradient-to-r from-forest-700 to-forest-500"
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: g.progress / 100 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.1, delay: 0.15 + i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                  />
                </div>
                <p className="mt-2.5 text-[11px] text-mist">
                  <span className="tnum font-semibold text-forest-800">{g.progress}%</span> complete · due {g.deadline}
                </p>
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
