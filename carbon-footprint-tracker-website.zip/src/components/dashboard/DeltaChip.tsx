import { TrendingDown, TrendingUp } from "lucide-react";

export function DeltaChip({ pct, suffix = "vs prev" }: { pct: number; suffix?: string }) {
  const good = pct <= 0;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ${
        good ? "bg-forest-600/10 text-forest-700" : "bg-[#c87f4f]/10 text-[#a55f2e]"
      }`}
    >
      {good ? <TrendingDown className="h-3 w-3" /> : <TrendingUp className="h-3 w-3" />}
      <span className="tnum">
        {good ? "−" : "+"}
        {Math.abs(pct).toFixed(1)}%
      </span>
      {suffix ? <span className="font-normal opacity-70">{suffix}</span> : null}
    </span>
  );
}
