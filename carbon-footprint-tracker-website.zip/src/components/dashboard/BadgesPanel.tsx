import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Lock } from "lucide-react";
import { BADGES } from "@/data/dashboard";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/utils/cn";

export function BadgesPanel() {
  const [openId, setOpenId] = useState<string | null>(null);
  const earnedCount = BADGES.filter((b) => b.earned).length;

  return (
    <section aria-labelledby="badges-title">
      <SectionHeading
        eyebrow="Milestones"
        title={
          <>
            Progress worth <em className="font-normal italic text-forest-700">celebrating</em>
          </>
        }
        description={`${earnedCount} of ${BADGES.length} badges earned. Small wins, made visible.`}
      />
      <div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {BADGES.map((b, i) => {
          const open = openId === b.id;
          return (
            <Reveal key={b.id} delay={(i % 4) * 0.07}>
              <button
                type="button"
                onClick={() => setOpenId(open ? null : b.id)}
                aria-expanded={open}
                className={cn(
                  "flex h-full w-full flex-col items-center rounded-2xl border p-5 text-center transition-all duration-500",
                  b.earned
                    ? "border-line bg-white/70 hover:-translate-y-1 hover:border-sage-300 hover:shadow-lift"
                    : "border-line bg-cream/60 opacity-80 hover:opacity-100",
                  open && "border-forest-700/50 shadow-card"
                )}
              >
                <span
                  className={cn(
                    "relative inline-flex h-14 w-14 items-center justify-center rounded-2xl transition-colors duration-300",
                    b.earned
                      ? "bg-forest-800 text-sage-200 shadow-[0_10px_24px_-10px_rgba(27,67,50,0.5)]"
                      : "bg-cream-deep text-mist"
                  )}
                >
                  <b.icon className="h-6 w-6" strokeWidth={1.7} />
                  {!b.earned && (
                    <span className="absolute -bottom-1.5 -right-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full border border-line bg-cream text-mist">
                      <Lock className="h-2.5 w-2.5" />
                    </span>
                  )}
                </span>
                <p className={cn("mt-3.5 text-sm font-medium", b.earned ? "text-forest-950" : "text-mist")}>
                  {b.title}
                </p>
                <p className="mt-0.5 text-[11px] text-mist">
                  {b.earned ? `Earned ${b.earnedDate}` : "Locked"}
                </p>
                <AnimatePresence initial={false}>
                  {open && (
                    <motion.span
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                      className="block overflow-hidden"
                    >
                      <span className="block border-t border-line pt-3 text-[11px] leading-relaxed text-mist">
                        {b.description}
                        <span className="mt-1.5 block font-medium text-forest-800">{b.hint}</span>
                      </span>
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}
