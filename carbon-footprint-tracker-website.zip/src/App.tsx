import { useEffect } from "react";
import { HashRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { ToastProvider } from "@/components/ui/Toast";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Page } from "@/components/layout/Page";
import { HomePage } from "@/pages/HomePage";
import { CalculatorPage } from "@/pages/CalculatorPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { AboutPage } from "@/pages/AboutPage";

/** Scrolls to top on navigation, or to the anchored element when a hash is present. */
function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.slice(1));
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - 88;
        window.scrollTo({ top, behavior: "smooth" });
        return;
      }
    }
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [pathname, hash]);
  return null;
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <Page>
              <HomePage />
            </Page>
          }
        />
        <Route
          path="/calculator"
          element={
            <Page>
              <CalculatorPage />
            </Page>
          }
        />
        <Route
          path="/dashboard"
          element={
            <Page>
              <DashboardPage />
            </Page>
          }
        />
        <Route
          path="/about"
          element={
            <Page>
              <AboutPage />
            </Page>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <HashRouter>
        <button
          type="button"
          onClick={() => {
            const main = document.getElementById("main");
            main?.focus();
            main?.scrollIntoView();
          }}
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-full focus:bg-forest-900 focus:px-5 focus:py-2.5 focus:text-sm focus:text-cream"
        >
          Skip to content
        </button>
        <ScrollManager />
        <Navbar />
        <main id="main" tabIndex={-1} className="outline-none">
          <AnimatedRoutes />
        </main>
        <Footer />
      </HashRouter>
    </ToastProvider>
  );
}
