/** Shared number / unit formatting helpers. */

export const fmtInt = (n: number): string =>
  new Intl.NumberFormat("en-US").format(Math.round(n));

export const fmtTonnes = (n: number, digits = 2): string =>
  n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });

export const fmtKg = (kg: number): string =>
  kg >= 1000 ? `${fmtTonnes(kg / 1000)} t` : `${fmtInt(kg)} kg`;

export const fmtPct = (n: number, digits = 0): string =>
  `${n.toFixed(digits)}%`;
