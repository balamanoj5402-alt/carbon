import type { MonthRecord } from "@/data/dashboard";

/** Builds a CSV from monthly records and triggers a download. */
export function exportMonthlyCsv(records: MonthRecord[]) {
  const header = "month,transport_t,energy_t,food_t,waste_t,total_t";
  const rows = records.map((r) =>
    [
      r.label,
      r.transport.toFixed(2),
      r.energy.toFixed(2),
      r.food.toFixed(2),
      r.waste.toFixed(2),
      r.total.toFixed(2),
    ].join(",")
  );
  const csv = [header, ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "verdant-footprint-export.csv";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
