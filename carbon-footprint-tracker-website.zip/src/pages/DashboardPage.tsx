import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  CalendarRange,
  Download,
  Flame,
  Lightbulb,
  Plus,
  TrendingDown,
  type LucideIcon,
} from "lucide-react";
import {
  CATEGORIES,
  MEMBER,
  deltaPct,
  monthlyHistory,
  monthKey,
  reductionStreak,
  type MonthRecord,
} from "@/data/dashboard";
import { MonthlyAreaChart, CategoryDonut } from "@/components/dashboard/charts";
import { GoalsPanel } from "@/components/dashboard/GoalsPanel";
import { BadgesPanel } from "@/components/dashboard/BadgesPanel";
import { HistoryTable } from "@/components/dashboard/HistoryTable";
import { AddEntryModal } from "@/components/dashboard/AddEntryModal";
import { DeltaChip } from "@/components/dashboard/DeltaChip";
import { useToast } from "@/components/ui/Toast";
import { Reveal } from "@/components/ui/Reveal";
import { useDocumentTitle } from "@/utils/useDocumentTitle";
import { exportMonthlyCsv } from "@/utils/export";
import { fmtTonnes } from "@/utils/format";
import { cn } from "@/utils/cn";

type Range = "3M" | "6M" | "12M" | "YTD";
const RANGES: Range[] = ["3M", "6M", "12M", "YTD"];

function SummaryCard({
  icon: Icon,
  label,
  value,
  unit,
  chip,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  unit: string;
  chip?: React.ReactNode;
}) {
  return (
    <div className="group h-full rounded-2xl border border-line bg-white/70 p-5 transition-all duration-500 hover:-translate-y-1 hover:shadow-lift">
      <div className="flex items-center justify-between gap-3">
        <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-sage-100 text-forest-700 transition-colors duration-300 group-hover:bg-forest-800 group-hover:text-cream">
          <Icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
        </span>
        {chip}
      </div>
      <p className="tnum mt-4 font-display text-[1.75rem] font-light leading-none text-forest-950">
        {value} <span className="text-sm font-normal text-mist">{unit}</span>
      </p>
      <p className="mt-2 text-xs text-mist">{label}</p>
    </div>
  );
}

export function DashboardPage() {
  useDocumentTitle(
    "Dashboard — Verdant",
    "Your monthly carbon footprint summary, category breakdown, goals, badges and history."
  );

  const toast = useToast();
  const [records, setRecords] = useState<MonthRecord[]>(monthlyHistory);
  const [range, setRange] = useState<Range>("12M");
  const [modalOpen, setModalOpen] = useState(false);

  const current = records[records.length - 1];
  const previous = records[records.length - 2];
  const first = records[0];
  const streak = reductionStreak(records);
  const monthDelta = deltaPct(current.total, previous.total);

  const ytd = useMemo(() => {
    const idx = records.findIndex((r) => r.label.startsWith("Jan 2026"));
    return records.slice(idx >= 0 ? idx : 0).reduce((s, r) => s + r.total, 0);
  }, [records]);

  const filtered = useMemo(() => {
    switch (range) {
      case "3M":
        return records.slice(-3);
      case "6M":
        return records.slice(-6);
      case "YTD": {
        const idx = records.findIndex((r) => r.label.startsWith("Jan 2026"));
        return records.slice(idx >= 0 ? idx : 0);
      }
      default:
        return records;
    }
  }, [records, range]);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  const handleSave = (record: MonthRecord, monthLabel: string, isNew: boolean) => {
    setRecords((prev) => {
      const rest = prev.filter((r) => r.label !== monthLabel);
      return [...rest, record].sort((a, b) => monthKey(a.label) - monthKey(b.label));
    });
    setModalOpen(false);
    toast.push(
      isNew
        ? `Entry added — ${monthLabel} logged at ${fmtTonnes(record.total)} t.`
        : `Entry updated — ${monthLabel} now ${fmtTonnes(record.total)} t.`
    );
  };

  return (
    <div className="bg-cream pb-24 pt-32 lg:pt-40">
      <div className="container-x">
        {/* Header */}
        <Reveal>
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-forest-700">
                {MEMBER.city} · {current.label}
              </p>
              <h1 className="mt-3 text-4xl font-light leading-[1.08] tracking-[-0.015em] text-forest-950 sm:text-5xl">
                {greeting}, <em className="font-normal italic text-forest-700">{MEMBER.name}.</em>
              </h1>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-mist">
                Your footprint is trending down — {streak} months in a row. Here
                is everything that moved the needle this month.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  exportMonthlyCsv(records);
                  toast.push("Your CSV export has started downloading.");
                }}
                className="btn-outline"
              >
                <Download className="h-4 w-4" />
                Export CSV
              </button>
              <button type="button" onClick={() => setModalOpen(true)} className="btn-primary group">
                <Plus className="h-4 w-4 transition-transform duration-300 group-hover:rotate-90" />
                Add manual entry
              </button>
            </div>
          </div>
        </Reveal>

        {/* Summary cards */}
        <div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Reveal delay={0.05} className="h-full">
            <SummaryCard
              icon={Activity}
              label={`This month · ${current.label}`}
              value={fmtTonnes(current.total)}
              unit="t CO₂e"
              chip={<DeltaChip pct={monthDelta} suffix="vs Jun" />}
            />
          </Reveal>
          <Reveal delay={0.1} className="h-full">
            <SummaryCard
              icon={CalendarRange}
              label="Year to date · 7 months"
              value={fmtTonnes(ytd)}
              unit="t"
              chip={
                <span className="chip border-forest-600/25 bg-forest-600/10 text-forest-700">on track</span>
              }
            />
          </Reveal>
          <Reveal delay={0.15} className="h-full">
            <SummaryCard
              icon={TrendingDown}
              label={`Reduction since ${first.label}`}
              value={fmtTonnes(first.total - current.total)}
              unit="t"
              chip={<DeltaChip pct={deltaPct(current.total, first.total)} suffix="total" />}
            />
          </Reveal>
          <Reveal delay={0.2} className="h-full">
            <SummaryCard
              icon={Flame}
              label="Consecutive reductions"
              value={String(streak)}
              unit="months"
              chip={
                <span className="chip border-forest-600/25 bg-forest-600/10 text-forest-700">personal best</span>
              }
            />
          </Reveal>
        </div>

        {/* Charts */}
        <div className="mt-6 grid gap-6 xl:grid-cols-12">
          <Reveal className="xl:col-span-7">
            <section
              aria-labelledby="trend-title"
              className="h-full rounded-3xl border border-line bg-white/70 p-6 shadow-card backdrop-blur-sm sm:p-7"
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 id="trend-title" className="text-lg font-medium tracking-tight text-forest-950">
                    Footprint trend
                  </h2>
                  <p className="mt-0.5 text-xs text-mist">Stacked monthly emissions by category</p>
                </div>
                <div
                  className="flex rounded-full border border-line bg-cream p-1"
                  role="tablist"
                  aria-label="Time range"
                >
                  {RANGES.map((r) => (
                    <button
                      key={r}
                      type="button"
                      role="tab"
                      aria-selected={range === r}
                      onClick={() => setRange(r)}
                      className={cn(
                        "relative rounded-full px-4 py-1.5 text-xs font-medium transition-colors duration-300",
                        range === r ? "text-cream" : "text-mist hover:text-forest-900"
                      )}
                    >
                      {range === r && (
                        <motion.span
                          layoutId="range-pill"
                          className="absolute inset-0 rounded-full bg-forest-800"
                          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                        />
                      )}
                      <span className="relative">{r}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-6">
                <MonthlyAreaChart key={range} data={filtered} />
              </div>
              <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
                {CATEGORIES.map((c) => (
                  <span key={c.key} className="flex items-center gap-2 text-xs text-mist">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: c.color }} />
                    {c.label}
                  </span>
                ))}
              </div>
            </section>
          </Reveal>

          <Reveal delay={0.1} className="xl:col-span-5">
            <section
              aria-labelledby="donut-title"
              className="flex h-full flex-col rounded-3xl border border-line bg-white/70 p-6 shadow-card backdrop-blur-sm sm:p-7"
            >
              <h2 id="donut-title" className="text-lg font-medium tracking-tight text-forest-950">
                This month's mix
              </h2>
              <p className="mt-0.5 text-xs text-mist">Where {fmtTonnes(current.total)} t came from</p>
              <div className="mt-4 flex-1">
                <CategoryDonut record={current} />
              </div>
              <div className="mt-4 space-y-2.5">
                {CATEGORIES.map((c, i) => {
                  const v = current[c.key as "transport" | "energy" | "food" | "waste"];
                  const pct = (v / current.total) * 100;
                  return (
                    <div key={c.key} className="flex items-center gap-3 text-sm">
                      <span className="flex w-28 items-center gap-2 text-ink/75">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ background: c.color }} />
                        {c.label}
                      </span>
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-cream-deep">
                        <motion.span
                          className="block h-full origin-left rounded-full"
                          style={{ background: c.color }}
                          initial={{ scaleX: 0 }}
                          whileInView={{ scaleX: pct / 100 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.9, delay: 0.2 + i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                        />
                      </div>
                      <span className="tnum w-16 text-right text-xs text-mist">
                        {fmtTonnes(v)} t · {Math.round(pct)}%
                      </span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-5 flex items-start gap-3 rounded-2xl bg-sage-100 p-4">
                <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-forest-800" />
                <p className="text-[13px] leading-snug text-forest-900">
                  <span className="font-semibold">Smart insight:</span> transport
                  remains your largest slice at {Math.round((current.transport / current.total) * 100)}%. Swapping
                  two car trips a week for rail could save ~0.18 t next month.
                </p>
              </div>
            </section>
          </Reveal>
        </div>

        {/* Goals + badges */}
        <div className="mt-20">
          <GoalsPanel />
        </div>
        <div className="mt-20">
          <BadgesPanel />
        </div>

        {/* History */}
        <div className="mt-20">
          <HistoryTable records={records} onAdd={() => setModalOpen(true)} />
        </div>
      </div>

      <AddEntryModal open={modalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} />
    </div>
  );
}
