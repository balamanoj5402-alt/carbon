import { useMemo, useRef, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Flame,
  Home,
  Recycle,
  Salad,
  TrainFront,
  Users,
  Zap,
  type LucideIcon,
} from "lucide-react";
import {
  calculateFootprint,
  defaultInputs,
  dietOptions,
  vehicleOptions,
  wasteOptions,
  type CalcInputs,
} from "@/data/calculator";
import { SegmentedControl, SliderRow, Stepper } from "@/components/calculator/controls";
import { ResultsPanel } from "@/components/calculator/ResultsPanel";
import { Reveal } from "@/components/ui/Reveal";
import { useDocumentTitle } from "@/utils/useDocumentTitle";

function FormCard({
  id,
  icon: Icon,
  title,
  blurb,
  children,
}: {
  id: string;
  icon: LucideIcon;
  title: string;
  blurb: string;
  children: ReactNode;
}) {
  return (
    <Reveal>
      <section
        aria-labelledby={id}
        className="rounded-3xl border border-line bg-white/70 p-6 shadow-card backdrop-blur-sm sm:p-8"
      >
        <header className="flex items-start gap-4">
          <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-forest-800 text-sage-200">
            <Icon className="h-5 w-5" strokeWidth={1.8} />
          </span>
          <div>
            <h3 id={id} className="text-lg font-medium tracking-tight text-forest-950">
              {title}
            </h3>
            <p className="mt-0.5 text-sm text-mist">{blurb}</p>
          </div>
        </header>
        <div className="mt-7 space-y-8">{children}</div>
      </section>
    </Reveal>
  );
}

export function CalculatorPage() {
  useDocumentTitle(
    "Carbon Calculator — Verdant",
    "Estimate your annual carbon footprint in five minutes — transport, home energy, food and waste — with a personalised reduction playbook."
  );

  const [inputs, setInputs] = useState<CalcInputs>(defaultInputs);
  const [submitted, setSubmitted] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const results = useMemo(() => calculateFootprint(inputs), [inputs]);

  const update = <K extends keyof CalcInputs>(key: K, value: CalcInputs[K]) =>
    setInputs((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = () => {
    setSubmitted(true);
    window.setTimeout(() => {
      reportRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 120);
  };

  return (
    <div className="bg-cream pb-24 pt-32 lg:pt-40">
      {/* Header */}
      <header className="container-x">
        <Reveal>
          <span className="eyebrow">Free calculator · no account needed</span>
        </Reveal>
        <Reveal delay={0.08}>
          <h1 className="mt-4 max-w-3xl text-4xl font-light leading-[1.08] tracking-[-0.015em] text-forest-950 sm:text-5xl">
            Your footprint, <em className="font-normal italic text-forest-700">made honest.</em>
          </h1>
        </Reveal>
        <Reveal delay={0.16}>
          <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-mist sm:text-base">
            Twenty questions about how you live. We convert your answers into a
            science-backed estimate of your annual CO₂e, show you where it
            comes from, and rank the changes that would cut it fastest.
          </p>
        </Reveal>
        <Reveal delay={0.22}>
          <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-mist">
            <span className="flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5 text-forest-700" /> Live results as you type
            </span>
            <span className="flex items-center gap-1.5">
              <Flame className="h-3.5 w-3.5 text-forest-700" /> Factors from EPA, DEFRA &amp; Exiobase
            </span>
            <span className="flex items-center gap-1.5">
              <Home className="h-3.5 w-3.5 text-forest-700" /> Your data never leaves this browser
            </span>
          </div>
        </Reveal>
      </header>

      {/* Body */}
      <div className="container-x mt-12 grid gap-8 lg:grid-cols-12">
        {/* Form */}
        <div className="space-y-6 lg:col-span-7">
          <FormCard
            id="card-household"
            icon={Users}
            title="Your household"
            blurb="Shared emissions are divided fairly across the people in your home."
          >
            <Stepper
              id="household"
              label="People in your household"
              hint="Including you. Home energy and waste are split per person."
              value={inputs.householdSize}
              min={1}
              max={8}
              onChange={(v) => update("householdSize", v)}
            />
          </FormCard>

          <FormCard
            id="card-transport"
            icon={TrainFront}
            title="Transport"
            blurb="Driving, public transit and flying — usually the biggest lever."
          >
            <SliderRow
              id="car-miles"
              label="Miles driven per week"
              value={inputs.carMilesWeek}
              min={0}
              max={600}
              step={5}
              unit="mi"
              hint="Your personal miles, across all cars you drive."
              onChange={(v) => update("carMilesWeek", v)}
            />
            <SegmentedControl
              id="vehicle"
              label="Main vehicle type"
              value={inputs.vehicleType}
              options={vehicleOptions}
              onChange={(v) => update("vehicleType", v)}
            />
            <SliderRow
              id="transit-miles"
              label="Public transport per month"
              value={inputs.transitMilesMonth}
              min={0}
              max={800}
              step={10}
              unit="mi"
              hint="Bus, tram, metro and regional rail combined."
              onChange={(v) => update("transitMilesMonth", v)}
            />
            <div className="grid gap-6 sm:grid-cols-2">
              <Stepper
                id="short-flights"
                label="Short flights per year"
                hint="Up to 3 hours each"
                value={inputs.shortFlights}
                max={24}
                onChange={(v) => update("shortFlights", v)}
              />
              <Stepper
                id="long-flights"
                label="Long flights per year"
                hint="Over 3 hours each"
                value={inputs.longFlights}
                max={12}
                onChange={(v) => update("longFlights", v)}
              />
            </div>
          </FormCard>

          <FormCard
            id="card-energy"
            icon={Home}
            title="Home energy"
            blurb="Electricity and heating, split per person in your home."
          >
            <SliderRow
              id="electricity"
              label="Electricity use per month"
              value={inputs.electricityKwh}
              min={0}
              max={3000}
              step={20}
              unit="kWh"
              hint="Find this on your utility bill — average EU home ≈ 350 kWh, US ≈ 880 kWh."
              onChange={(v) => update("electricityKwh", v)}
            />
            <SliderRow
              id="renewable"
              label="Renewable energy share"
              value={inputs.renewablePct}
              min={0}
              max={100}
              step={5}
              unit="%"
              hint="From a green tariff, rooftop solar or community wind."
              onChange={(v) => update("renewablePct", v)}
            />
            <SliderRow
              id="gas"
              label="Natural gas per month"
              value={inputs.gasM3}
              min={0}
              max={400}
              step={5}
              unit="m³"
              hint="Heating, hot water and cooking. Leave at 0 if fully electric."
              onChange={(v) => update("gasM3", v)}
            />
          </FormCard>

          <FormCard
            id="card-food"
            icon={Salad}
            title="Food"
            blurb="What you eat — and how much of it goes to waste."
          >
            <SegmentedControl
              id="diet"
              label="Diet style"
              value={inputs.diet}
              options={dietOptions}
              onChange={(v) => update("diet", v)}
            />
            <SegmentedControl
              id="food-waste"
              label="Household food waste"
              value={inputs.foodWaste}
              options={wasteOptions}
              onChange={(v) => update("foodWaste", v)}
            />
          </FormCard>

          <FormCard
            id="card-waste"
            icon={Recycle}
            title="Waste & recycling"
            blurb="What goes to landfill, and what gets a second life."
          >
            <SliderRow
              id="waste-kg"
              label="General waste per week"
              value={inputs.wasteKgWeek}
              min={0}
              max={60}
              step={1}
              unit="kg"
              hint="Everything that ends up in the residual bin."
              onChange={(v) => update("wasteKgWeek", v)}
            />
            <SliderRow
              id="recycling"
              label="Recycled or composted"
              value={inputs.recyclingPct}
              min={0}
              max={100}
              step={5}
              unit="%"
              hint="Paper, metal, glass, organics — anything diverted from landfill."
              onChange={(v) => update("recyclingPct", v)}
            />
          </FormCard>
        </div>

        {/* Sticky results */}
        <aside className="lg:col-span-5" ref={reportRef}>
          <div className="lg:sticky lg:top-28">
            <ResultsPanel
              inputs={inputs}
              results={results}
              submitted={submitted}
              onSubmit={handleSubmit}
              onEdit={() => setSubmitted(false)}
            />
            {!submitted && (
              <p className="mt-4 hidden text-center text-xs text-mist lg:block">
                Tip: your report benchmarks you against 4.7 t — the global per-person average.
              </p>
            )}
          </div>
        </aside>
      </div>

      {/* Bottom CTA */}
      <Reveal className="container-x mt-20">
        <div className="flex flex-col items-center justify-between gap-6 rounded-3xl border border-line bg-forest-900 px-8 py-10 text-center sm:px-12 lg:flex-row lg:text-left">
          <div>
            <h2 className="text-2xl font-light leading-snug text-cream sm:text-3xl">
              Tired of guessing? <em className="font-normal italic text-sage-300">Track it monthly.</em>
            </h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-cream/65">
              Verdant members who check in monthly reduce their footprint twice
              as fast as one-time calculators. Your history, goals and badges
              are waiting.
            </p>
          </div>
          <Link
            to="/dashboard"
            className="btn group shrink-0 bg-cream px-7 py-3.5 text-sm font-semibold text-forest-950 hover:-translate-y-0.5 hover:bg-sage-200 hover:shadow-soft"
          >
            See the dashboard
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
          </Link>
        </div>
      </Reveal>
    </div>
  );
}
