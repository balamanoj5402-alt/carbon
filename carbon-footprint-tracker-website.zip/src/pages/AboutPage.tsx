import { useState, type FormEvent } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Leaf,
  Mail,
  MapPin,
  Plus,
  ShieldCheck,
} from "lucide-react";
import missionImage from "@/assets/images/mission.jpg";
import riverImage from "@/assets/images/river.jpg";
import energyImage from "@/assets/images/energy.jpg";
import { METHOD_SOURCES, VALUES, FAQ } from "@/data/site";
import { Counter } from "@/components/ui/Counter";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useToast } from "@/components/ui/Toast";
import { useDocumentTitle } from "@/utils/useDocumentTitle";

const IMPACT = [
  { value: 128400, suffix: "+", label: "members on the platform" },
  { value: 41600, suffix: "", label: "tonnes tracked in 2025" },
  { value: 23, suffix: "%", label: "average reduction in 6 months" },
  { value: 380, suffix: "+", label: "partner organisations" },
];

const CONTACT_CARDS = [
  {
    icon: Mail,
    title: "Email us",
    lines: ["hello@verdant.earth", "press@verdant.earth"],
  },
  {
    icon: MapPin,
    title: "Visit the studio",
    lines: ["Vesterbrogade 64", "1620 Copenhagen V, Denmark"],
  },
  {
    icon: Clock,
    title: "Response time",
    lines: ["Within 2 business days", "Mon–Fri, 09:00–17:00 CET"],
  },
];

interface ContactForm {
  name: string;
  email: string;
  topic: string;
  message: string;
}

type FormStatus = "idle" | "sending" | "sent";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function AboutPage() {
  useDocumentTitle(
    "About & Contact — Verdant",
    "The mission behind Verdant: making carbon visible so reduction becomes inevitable. Contact us, explore our method, or join the newsletter."
  );

  const toast = useToast();
  const [form, setForm] = useState<ContactForm>({ name: "", email: "", topic: "General question", message: "" });
  const [errors, setErrors] = useState<Partial<Record<keyof ContactForm, string>>>({});
  const [status, setStatus] = useState<FormStatus>("idle");

  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterStatus, setNewsletterStatus] = useState<FormStatus>("idle");

  const update = (key: keyof ContactForm, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const submitContact = async (ev: FormEvent) => {
    ev.preventDefault();
    const e: Partial<Record<keyof ContactForm, string>> = {};
    if (!form.name.trim()) e.name = "Please tell us your name.";
    if (!EMAIL_RE.test(form.email)) e.email = "Enter a valid email address.";
    if (form.message.trim().length < 10) e.message = "Give us a little more detail (10+ characters).";
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setStatus("sending");
    await new Promise((r) => setTimeout(r, 900));
    setStatus("sent");
    toast.push("Message sent — we reply within two business days.");
  };

  const submitNewsletter = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!EMAIL_RE.test(newsletterEmail)) {
      toast.push("Please enter a valid email address.", "info");
      return;
    }
    setNewsletterStatus("sending");
    await new Promise((r) => setTimeout(r, 800));
    setNewsletterStatus("sent");
    toast.push("Welcome to The Monthly Briefing.");
  };

  return (
    <div className="bg-cream">
      {/* ---------------------------------- Hero */}
      <section className="relative overflow-hidden bg-forest-950 pb-24 pt-36 text-cream lg:pb-32 lg:pt-44">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-40 top-0 h-[26rem] w-[26rem] rounded-full bg-forest-600/20 blur-3xl"
        />
        <div className="container-x relative grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <Reveal>
              <span className="eyebrow text-sage-300">About Verdant</span>
            </Reveal>
            <Reveal delay={0.08}>
              <h1 className="mt-5 text-4xl font-light leading-[1.08] tracking-[-0.015em] sm:text-5xl lg:text-[3.6rem]">
                We make carbon visible, so reduction becomes{" "}
                <em className="font-normal italic text-sage-300">inevitable.</em>
              </h1>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-cream/70 sm:text-base">
                Most carbon tools hand you a number and leave you drowning in
                guilt. We built the opposite: a calm, rigorous platform that
                shows you exactly where your emissions come from and exactly
                what to do next — then walks the path with you, month after
                month.
              </p>
            </Reveal>
            <Reveal delay={0.24}>
              <dl className="mt-10 flex flex-wrap gap-x-10 gap-y-6">
                {[
                  ["Founded", "2021"],
                  ["Team", "34 people"],
                  ["Reach", "12 countries"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dd className="tnum font-display text-3xl font-light text-sage-300">{v}</dd>
                    <dt className="mt-1 text-xs uppercase tracking-[0.18em] text-cream/50">{k}</dt>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          <Reveal delay={0.2}>
            <div className="relative">
              <img
                src={missionImage}
                alt="Hands holding a young tree sapling with soil"
                className="aspect-[4/5] w-full rounded-[2rem] border border-white/10 object-cover shadow-soft"
                loading="eager"
              />
              <div className="animate-float-y absolute -bottom-5 -left-4 flex items-center gap-2.5 rounded-full border border-white/15 bg-forest-900/90 px-4 py-2.5 text-xs font-medium text-cream backdrop-blur sm:-left-8">
                <ShieldCheck className="h-4 w-4 text-sage-300" />
                B Corp certified · GDPR compliant
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------------- Mission / story */}
      <section id="mission" className="scroll-mt-28 py-24 lg:py-32">
        <div className="container-x grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <img
              src={riverImage}
              alt="Aerial view of a river winding through untouched forest"
              className="aspect-[5/4] w-full rounded-[2rem] border border-line object-cover shadow-card"
              loading="lazy"
            />
          </Reveal>
          <div>
            <SectionHeading
              eyebrow="Our mission"
              title={
                <>
                  Climate action needs a <em className="font-normal italic text-forest-700">feedback loop</em>
                </>
              }
            />
            <Reveal delay={0.14}>
              <div className="mt-6 space-y-5 text-[15px] leading-relaxed text-ink/80">
                <p>
                  In 2021, our founders — a climate scientist and a product
                  designer — tried to calculate their own household emissions.
                  The tools were either shallow quizzes or enterprise
                  spreadsheets, and almost none of them told you what to do
                  differently tomorrow.
                </p>
                <p>
                  So we built the feedback loop ourselves: honest measurement,
                  clear attribution, and a ranked plan that respects how real
                  households actually live. Today, 128,000 people use Verdant
                  to turn good intentions into downward curves.
                </p>
                <p>
                  We believe individual action is not a distraction from
                  systemic change — it is the soil it grows in. People who can
                  see their footprint vote, buy and organise differently.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------------------------------- Values */}
      <section className="border-y border-line bg-cream-deep/50 py-24 lg:py-28">
        <div className="container-x">
          <SectionHeading
            eyebrow="What we stand for"
            title={
              <>
                Three principles, <em className="font-normal italic text-forest-700">held without compromise</em>
              </>
            }
            align="center"
            className="mx-auto items-center"
          />
          <div className="mt-14 grid gap-5 md:grid-cols-3">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.1}>
                <article className="flex h-full flex-col rounded-2xl border border-line bg-white/70 p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-lift">
                  <span className="font-display text-4xl font-light italic text-forest-600">
                    0{i + 1}
                  </span>
                  <h3 className="mt-4 text-lg font-medium text-forest-950">{v.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-mist">{v.body}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------- Method */}
      <section id="method" className="scroll-mt-28 py-24 lg:py-32">
        <div className="container-x grid items-start gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="lg:sticky lg:top-28">
            <Reveal>
              <img
                src={energyImage}
                alt="Wind turbines on green hills"
                className="aspect-[4/3] w-full rounded-[2rem] border border-line object-cover shadow-card"
                loading="lazy"
              />
            </Reveal>
            <Reveal delay={0.12}>
              <div className="mt-6 rounded-2xl border border-line bg-white/70 p-5">
                <p className="flex items-center gap-2 text-sm font-semibold text-forest-950">
                  <Leaf className="h-4 w-4 text-forest-700" />
                  How we calculate
                </p>
                <p className="mt-2 text-[13px] leading-relaxed text-mist">
                  Every factor is versioned and updated quarterly. Your
                  estimate always shows the dataset version behind it — no
                  black boxes, no hidden assumptions.
                </p>
              </div>
            </Reveal>
          </div>

          <div>
            <SectionHeading
              eyebrow="Method & data"
              title={
                <>
                  Built on the world's best <em className="font-normal italic text-forest-700">open climate data</em>
                </>
              }
              description="We don't invent factors. We assemble the most respected public datasets, apply them transparently, and cite every one."
            />
            <div className="mt-10 grid gap-4 sm:grid-cols-2">
              {METHOD_SOURCES.map((s, i) => (
                <Reveal key={s.name} delay={(i % 2) * 0.08}>
                  <div className="group h-full rounded-2xl border border-line bg-white/70 p-5 transition-all duration-500 hover:-translate-y-1 hover:border-sage-300 hover:shadow-lift">
                    <p className="font-display text-lg italic text-forest-900">{s.name}</p>
                    <p className="mt-1.5 text-[13px] leading-snug text-mist">{s.role}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------------- Impact */}
      <section id="impact" className="scroll-mt-28 border-y border-line bg-forest-950 py-20 text-cream">
        <div className="container-x">
          <Reveal>
            <p className="text-center text-[11px] font-semibold uppercase tracking-[0.26em] text-sage-300">
              The impact so far
            </p>
          </Reveal>
          <div className="mt-12 grid grid-cols-2 gap-x-8 gap-y-10 lg:grid-cols-4">
            {IMPACT.map((s, i) => (
              <Reveal key={s.label} delay={i * 0.08}>
                <div className="text-center">
                  <p className="font-display text-4xl font-light tracking-tight text-cream sm:text-5xl">
                    <Counter value={s.value} suffix={s.suffix} />
                  </p>
                  <p className="mx-auto mt-2.5 max-w-[15rem] text-sm leading-snug text-cream/60">{s.label}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------- FAQ */}
      <section className="py-24 lg:py-32">
        <div className="container-x max-w-3xl">
          <SectionHeading
            eyebrow="Questions"
            title={
              <>
                Asked <em className="font-normal italic text-forest-700">often</em>
              </>
            }
            align="center"
            className="mx-auto items-center"
          />
          <div className="mt-12 divide-y divide-line border-y border-line">
            {FAQ.map((item, i) => (
              <details key={item.q} className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6 [&::-webkit-details-marker]:hidden">
                  <span className="text-base font-medium text-forest-950 transition-colors group-hover:text-forest-700">
                    {item.q}
                  </span>
                  <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line text-forest-700 transition-transform duration-300 group-open:rotate-45">
                    <Plus className="h-4 w-4" />
                  </span>
                </summary>
                <p
                  className="mt-3 max-w-2xl text-sm leading-relaxed text-mist"
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------- Contact */}
      <section id="contact" className="scroll-mt-28 border-t border-line bg-cream-deep/50 py-24 lg:py-32">
        <div className="container-x grid gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          <div>
            <SectionHeading
              eyebrow="Contact"
              title={
                <>
                  Talk to a <em className="font-normal italic text-forest-700">human</em>
                </>
              }
              description="Questions, partnerships, press or just a correction to our data — we read everything."
            />
            <div className="mt-10 space-y-4">
              {CONTACT_CARDS.map((c, i) => (
                <Reveal key={c.title} delay={i * 0.08}>
                  <div className="flex items-start gap-4 rounded-2xl border border-line bg-white/70 p-5">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sage-100 text-forest-700">
                      <c.icon className="h-5 w-5" strokeWidth={1.8} />
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-forest-950">{c.title}</p>
                      {c.lines.map((l) => (
                        <p key={l} className="mt-0.5 text-sm text-mist">
                          {l.includes("@") ? (
                            <a href={`mailto:${l}`} className="transition-colors hover:text-forest-800">
                              {l}
                            </a>
                          ) : (
                            l
                          )}
                        </p>
                      ))}
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          <Reveal delay={0.1}>
            <div className="rounded-3xl border border-line bg-white/80 p-6 shadow-card backdrop-blur-sm sm:p-9">
              {status === "sent" ? (
                <div className="flex min-h-[26rem] flex-col items-center justify-center text-center">
                  <span className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-sage-100">
                    <CheckCircle2 className="h-8 w-8 text-forest-700" />
                  </span>
                  <h3 className="mt-6 text-2xl font-medium text-forest-950">Message received</h3>
                  <p className="mt-2 max-w-sm text-sm leading-relaxed text-mist">
                    Thanks, {form.name.split(" ")[0] || "friend"} — we'll get
                    back to you at {form.email} within two business days.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setForm({ name: "", email: "", topic: "General question", message: "" });
                      setStatus("idle");
                    }}
                    className="btn-outline mt-8"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={submitContact} noValidate>
                  <h3 className="text-xl font-medium tracking-tight text-forest-950">Send us a message</h3>
                  <p className="mt-1 text-sm text-mist">All fields marked with an asterisk are required.</p>

                  <div className="mt-7 grid gap-5 sm:grid-cols-2">
                    <div>
                      <label htmlFor="c-name" className="text-sm font-medium text-ink/85">
                        Name <span aria-hidden="true" className="text-forest-700">*</span>
                      </label>
                      <input
                        id="c-name"
                        type="text"
                        value={form.name}
                        onChange={(e) => update("name", e.target.value)}
                        placeholder="Ada Lindgren"
                        className="input-field mt-2"
                        aria-invalid={!!errors.name}
                      />
                      {errors.name && (
                        <p className="mt-1.5 text-xs text-[#a55f2e]" role="alert">{errors.name}</p>
                      )}
                    </div>
                    <div>
                      <label htmlFor="c-email" className="text-sm font-medium text-ink/85">
                        Email <span aria-hidden="true" className="text-forest-700">*</span>
                      </label>
                      <input
                        id="c-email"
                        type="email"
                        value={form.email}
                        onChange={(e) => update("email", e.target.value)}
                        placeholder="ada@example.com"
                        className="input-field mt-2"
                        aria-invalid={!!errors.email}
                      />
                      {errors.email && (
                        <p className="mt-1.5 text-xs text-[#a55f2e]" role="alert">{errors.email}</p>
                      )}
                    </div>
                  </div>

                  <div className="mt-5">
                    <label htmlFor="c-topic" className="text-sm font-medium text-ink/85">Topic</label>
                    <select
                      id="c-topic"
                      value={form.topic}
                      onChange={(e) => update("topic", e.target.value)}
                      className="input-field mt-2"
                    >
                      {["General question", "Product & support", "Partnerships", "Press & media", "Careers"].map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="mt-5">
                    <label htmlFor="c-message" className="text-sm font-medium text-ink/85">
                      Message <span aria-hidden="true" className="text-forest-700">*</span>
                    </label>
                    <textarea
                      id="c-message"
                      rows={6}
                      value={form.message}
                      onChange={(e) => update("message", e.target.value)}
                      placeholder="Tell us what's on your mind…"
                      className="input-field mt-2 resize-none"
                      aria-invalid={!!errors.message}
                    />
                    {errors.message && (
                      <p className="mt-1.5 text-xs text-[#a55f2e]" role="alert">{errors.message}</p>
                    )}
                  </div>

                  <button type="submit" disabled={status === "sending"} className="btn-primary group mt-7 w-full py-3.5 sm:w-auto sm:px-10">
                    {status === "sending" ? (
                      <>
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-cream/40 border-t-cream" />
                        Sending…
                      </>
                    ) : (
                      <>
                        Send message
                        <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------------------------- Newsletter */}
      <section id="newsletter" className="scroll-mt-28 bg-forest-950 py-20 lg:py-24">
        <div className="container-x">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <Reveal>
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-sage-300">
                  The Monthly Briefing
                </p>
                <h2 className="mt-4 text-3xl font-light leading-tight text-cream sm:text-4xl">
                  One email a month. <em className="font-normal italic text-sage-300">Zero noise.</em>
                </h2>
                <p className="mt-4 max-w-md text-sm leading-relaxed text-cream/65">
                  The three numbers that moved in climate this month, one
                  practical reduction experiment, and a short essay from our
                  science team. Read in under five minutes.
                </p>
              </div>
            </Reveal>
            <Reveal delay={0.12}>
              <div className="rounded-3xl border border-white/10 bg-white/5 p-7 backdrop-blur sm:p-9">
                {newsletterStatus === "sent" ? (
                  <div className="flex items-start gap-4">
                    <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-sage-300/15">
                      <CheckCircle2 className="h-6 w-6 text-sage-300" />
                    </span>
                    <div>
                      <p className="text-lg font-medium text-cream">You're on the list.</p>
                      <p className="mt-1.5 text-sm leading-relaxed text-cream/60">
                        First briefing arrives at the start of next month. No
                        spam, no tracking pixels, unsubscribe in one click.
                      </p>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={submitNewsletter} className="flex flex-col gap-3 sm:flex-row" noValidate>
                    <label htmlFor="nl-email" className="sr-only">
                      Email address
                    </label>
                    <input
                      id="nl-email"
                      type="email"
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full rounded-full border border-white/20 bg-white/10 px-5 py-3.5 text-sm text-cream placeholder:text-cream/40 transition focus:border-sage-300 focus:outline-none focus:ring-2 focus:ring-sage-300/30"
                    />
                    <button
                      type="submit"
                      disabled={newsletterStatus === "sending"}
                      className="btn group shrink-0 bg-cream px-7 py-3.5 text-sm font-semibold text-forest-950 hover:-translate-y-0.5 hover:bg-sage-200 hover:shadow-soft"
                    >
                      {newsletterStatus === "sending" ? (
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-forest-800/30 border-t-forest-800" />
                      ) : (
                        <>
                          Subscribe
                          <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                        </>
                      )}
                    </button>
                  </form>
                )}
                <p className="mt-4 text-[11px] leading-relaxed text-cream/40">
                  8,200 readers · 34% open rate · sent on the first Tuesday of
                  every month
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
}
