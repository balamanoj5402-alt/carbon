import { Hero } from "@/components/home/Hero";
import { Stats } from "@/components/home/Stats";
import { StandardsMarquee } from "@/components/home/StandardsMarquee";
import { Features } from "@/components/home/Features";
import { HowItWorks } from "@/components/home/HowItWorks";
import { PlatformPreview } from "@/components/home/PlatformPreview";
import { Testimonials } from "@/components/home/Testimonials";
import { CtaBand } from "@/components/home/CtaBand";
import { useDocumentTitle } from "@/utils/useDocumentTitle";

export function HomePage() {
  useDocumentTitle(
    "Verdant — Carbon Footprint Tracker",
    "Measure, understand and reduce your carbon footprint across transport, home energy, food and waste — with science-backed data and a personalised reduction plan."
  );

  return (
    <>
      <Hero />
      <Stats />
      <StandardsMarquee />
      <Features />
      <HowItWorks />
      <PlatformPreview />
      <Testimonials />
      <CtaBand />
    </>
  );
}
