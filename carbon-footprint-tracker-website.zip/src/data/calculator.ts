import {
  Bike,
  Car,
  Carrot,
  Flame,
  Leaf,
  Plane,
  Recycle,
  Salad,
  TrainFront,
  TrendingDown,
  Zap,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export type VehicleType = "petrol" | "diesel" | "hybrid" | "phev" | "ev";
export type DietType = "heavy" | "moderate" | "low" | "vegetarian" | "vegan";
export type WasteLevel = "low" | "average" | "high";

export interface CalcInputs {
  householdSize: number;
  carMilesWeek: number;
  vehicleType: VehicleType;
  transitMilesMonth: number;
  shortFlights: number;
  longFlights: number;
  electricityKwh: number;
  renewablePct: number;
  gasM3: number;
  diet: DietType;
  foodWaste: WasteLevel;
  wasteKgWeek: number;
  recyclingPct: number;
}

export const defaultInputs: CalcInputs = {
  householdSize: 2,
  carMilesWeek: 180,
  vehicleType: "petrol",
  transitMilesMonth: 60,
  shortFlights: 4,
  longFlights: 2,
  electricityKwh: 860,
  renewablePct: 20,
  gasM3: 110,
  diet: "moderate",
  foodWaste: "average",
  wasteKgWeek: 18,
  recyclingPct: 35,
};

export const vehicleOptions: { value: VehicleType; label: string }[] = [
  { value: "petrol", label: "Petrol" },
  { value: "diesel", label: "Diesel" },
  { value: "hybrid", label: "Hybrid" },
  { value: "phev", label: "PHEV" },
  { value: "ev", label: "Electric" },
];

export const dietOptions: { value: DietType; label: string; blurb: string }[] = [
  { value: "heavy", label: "Meat daily", blurb: "Meat or fish with most meals" },
  { value: "moderate", label: "A few times a week", blurb: "Meat or fish 3–5 times weekly" },
  { value: "low", label: "Low-meat", blurb: "Meat or fish 1–2 times weekly" },
  { value: "vegetarian", label: "Vegetarian", blurb: "No meat or fish, dairy ok" },
  { value: "vegan", label: "Vegan", blurb: "Plant-based only" },
];

export const wasteOptions: { value: WasteLevel; label: string; blurb: string }[] = [
  { value: "low", label: "Low", blurb: "I rarely throw food away" },
  { value: "average", label: "Average", blurb: "Some food gets binned weekly" },
  { value: "high", label: "High", blurb: "I regularly waste meals" },
];

/* ------------------------------------------------------------------ */
/* Emission factors (kg CO₂e per unit)                                 */
/* ------------------------------------------------------------------ */

const VEHICLE_KG_PER_MILE: Record<VehicleType, number> = {
  petrol: 0.4,
  diesel: 0.42,
  hybrid: 0.26,
  phev: 0.21,
  ev: 0.12,
};

const TRANSIT_KG_PER_MILE = 0.09;
const SHORT_FLIGHT_KG = 130; // one-way, ≤ 3 h
const LONG_FLIGHT_KG = 520; // one-way, > 3 h
const ELECTRICITY_KG_PER_KWH = 0.42;
const GAS_KG_PER_M3 = 2.2;

const DIET_KG_PER_YEAR: Record<DietType, number> = {
  heavy: 3300,
  moderate: 2500,
  low: 1900,
  vegetarian: 1650,
  vegan: 1450,
};

const FOOD_WASTE_MULT: Record<WasteLevel, number> = {
  low: 1.0,
  average: 1.09,
  high: 1.18,
};

const LANDFILL_KG_PER_KG = 0.75;
const RECYCLED_KG_PER_KG = 0.12;

/* ------------------------------------------------------------------ */
/* Results                                                             */
/* ------------------------------------------------------------------ */

export interface CategoryResult {
  key: string;
  label: string;
  kg: number;
  pct: number;
}

export interface Benchmark {
  label: string;
  tonnes: number;
  note: string;
}

export interface CalcResults {
  totalKg: number;
  totalTonnes: number;
  categories: CategoryResult[];
}

export const BENCHMARKS: Benchmark[] = [
  { label: "United States average", tonnes: 14.9, note: "Per capita, 2023" },
  { label: "European Union average", tonnes: 7.4, note: "Per capita, 2023" },
  { label: "Global average", tonnes: 4.7, note: "Per capita, 2023" },
  { label: "1.5 °C compatible path", tonnes: 2.5, note: "Per capita by 2030" },
];

export function calculateFootprint(i: CalcInputs): CalcResults {
  const household = Math.max(1, i.householdSize);

  // Transport (personal)
  const car = i.carMilesWeek * 52 * VEHICLE_KG_PER_MILE[i.vehicleType];
  const transit = i.transitMilesMonth * 12 * TRANSIT_KG_PER_MILE;
  const flights = i.shortFlights * SHORT_FLIGHT_KG + i.longFlights * LONG_FLIGHT_KG;
  const transport = car + transit + flights;

  // Home energy (split across household)
  const gridFactor = 1 - (i.renewablePct / 100) * 0.95;
  const electricity = i.electricityKwh * 12 * ELECTRICITY_KG_PER_KWH * gridFactor;
  const gas = i.gasM3 * 12 * GAS_KG_PER_M3;
  const energy = (electricity + gas) / household;

  // Food (per person)
  const food = DIET_KG_PER_YEAR[i.diet] * FOOD_WASTE_MULT[i.foodWaste];

  // Waste (split across household)
  const landfillShare = 1 - i.recyclingPct / 100;
  const wasteKg =
    i.wasteKgWeek *
    52 *
    (landfillShare * LANDFILL_KG_PER_KG + (i.recyclingPct / 100) * RECYCLED_KG_PER_KG);
  const waste = wasteKg / household;

  const totalKg = transport + energy + food + waste;

  const defs: { key: string; label: string; kg: number }[] = [
    { key: "transport", label: "Transport", kg: transport },
    { key: "energy", label: "Home energy", kg: energy },
    { key: "food", label: "Food", kg: food },
    { key: "waste", label: "Waste", kg: waste },
  ];

  const categories: CategoryResult[] = defs.map((d) => ({
    ...d,
    pct: totalKg > 0 ? (d.kg / totalKg) * 100 : 0,
  }));

  return {
    totalKg,
    totalTonnes: totalKg / 1000,
    categories,
  };
}

/* ------------------------------------------------------------------ */
/* Suggestions                                                         */
/* ------------------------------------------------------------------ */

export interface Suggestion {
  id: string;
  icon: LucideIcon;
  tag: string;
  title: string;
  body: string;
  savingTonnes: number;
}

const DIET_CHAIN: DietType[] = ["heavy", "moderate", "low", "vegetarian", "vegan"];

export function getSuggestions(i: CalcInputs): Suggestion[] {
  const out: Suggestion[] = [];
  const household = Math.max(1, i.householdSize);

  // Vehicle electrification
  if ((i.vehicleType === "petrol" || i.vehicleType === "diesel") && i.carMilesWeek >= 80) {
    const saving = (i.carMilesWeek * 52 * (VEHICLE_KG_PER_MILE[i.vehicleType] - VEHICLE_KG_PER_MILE.ev)) / 1000;
    out.push({
      id: "ev",
      icon: Car,
      tag: "Transport",
      title: "Make your next car electric or hybrid",
      body: `At ${i.carMilesWeek} miles a week, electrifying your driving is your single biggest transport lever — and second-hand EVs now cost less to run than petrol in most markets.`,
      savingTonnes: saving,
    });
  }

  // Mode shift
  if (i.carMilesWeek >= 120) {
    const saving = (i.carMilesWeek * 52 * 0.2 * VEHICLE_KG_PER_MILE[i.vehicleType]) / 1000;
    out.push({
      id: "mode-shift",
      icon: Bike,
      tag: "Transport",
      title: "Replace 20% of car trips with rail, bike or walking",
      body: "One in five car miles swapped for a train, bus or bike is the fastest short-term win for most drivers — and it compounds once it becomes a habit.",
      savingTonnes: saving,
    });
  }

  // Flights
  if (i.longFlights >= 1) {
    out.push({
      id: "long-flight",
      icon: Plane,
      tag: "Transport",
      title: `Skip one long-haul flight (${i.longFlights} currently)`,
      body: "A single long-haul round trip is roughly a tonne of CO₂e. Train or stay closer to home once, and you've matched months of smaller changes.",
      savingTonnes: i.longFlights * LONG_FLIGHT_KG * 0.6 / 1000,
    });
  }
  if (i.shortFlights >= 4) {
    out.push({
      id: "short-flight",
      icon: Plane,
      tag: "Transport",
      title: "Swap two short flights for rail",
      body: "Flights under three hours are often beatable by train once airport time is counted — and at a fraction of the emissions.",
      savingTonnes: (2 * SHORT_FLIGHT_KG) / 1000,
    });
  }

  // Renewable electricity
  if (i.renewablePct < 80) {
    const saving = (i.electricityKwh * 12 * ELECTRICITY_KG_PER_KWH * 0.95 * (1 - i.renewablePct / 100)) / 1000 / household;
    out.push({
      id: "renewable",
      icon: Zap,
      tag: "Home energy",
      title: "Switch to a renewable electricity tariff",
      body: "A five-minute switch with most providers. Green tariffs are now within a few percent of standard rates across much of Europe and North America.",
      savingTonnes: saving,
    });
  }

  // Gas / heating
  if (i.gasM3 >= 90) {
    const saving = (i.gasM3 * 12 * GAS_KG_PER_M3 * 0.4) / 1000 / household;
    out.push({
      id: "heating",
      icon: Flame,
      tag: "Home energy",
      title: "Cut heating demand by 40% with insulation & controls",
      body: "Draught-proofing, loft insulation and a smart thermostat pay back in under three winters. A heat pump finishes the job when your boiler retires.",
      savingTonnes: saving,
    });
  }

  // Diet step-down
  const dietIdx = DIET_CHAIN.indexOf(i.diet);
  if (dietIdx < DIET_CHAIN.length - 1) {
    const next = DIET_CHAIN[dietIdx + 1];
    const saving = (DIET_KG_PER_YEAR[i.diet] - DIET_KG_PER_YEAR[next]) * FOOD_WASTE_MULT[i.foodWaste] / 1000;
    out.push({
      id: "diet",
      icon: Salad,
      tag: "Food",
      title: `Move one step down the food ladder — to “${dietOptions[dietIdx + 1].label.toLowerCase()}”`,
      body: "You don't need to go vegan overnight. Each rung of the ladder removes roughly half a tonne a year — and most people barely notice the difference.",
      savingTonnes: saving,
    });
  }

  // Food waste
  if (i.foodWaste !== "low") {
    const saving = (DIET_KG_PER_YEAR[i.diet] * (FOOD_WASTE_MULT[i.foodWaste] - FOOD_WASTE_MULT.low)) / 1000;
    out.push({
      id: "food-waste",
      icon: Carrot,
      tag: "Food",
      title: "Halve the food you throw away",
      body: "Meal planning, a shopping list and a freezer audit remove most household food waste — and they save money before they save carbon.",
      savingTonnes: saving,
    });
  }

  // Recycling
  if (i.recyclingPct < 60) {
    const landfillShare = 1 - i.recyclingPct / 100;
    const targetShare = 0.4;
    const saving =
      (i.wasteKgWeek * 52 * Math.max(0, landfillShare - targetShare) * (LANDFILL_KG_PER_KG - RECYCLED_KG_PER_KG)) /
      1000 /
      household;
    out.push({
      id: "recycling",
      icon: Recycle,
      tag: "Waste",
      title: "Lift recycling & composting to 60% of your waste",
      body: "Sorting paper, metal and glass — plus a small compost bin for organics — keeps methane out of landfill and materials in the loop.",
      savingTonnes: saving,
    });
  }

  // Habit anchor — always present
  out.push({
    id: "track",
    icon: TrendingDown,
    tag: "Habit",
    title: "Track monthly and watch the curve bend",
    body: "People who log their footprint monthly reduce it twice as fast as one-time calculators. Small, consistent review is the whole game.",
    savingTonnes: 0,
  });

  return out
    .sort((a, b) => b.savingTonnes - a.savingTonnes)
    .slice(0, 6)
    .map((s) => ({ ...s, savingTonnes: Math.round(s.savingTonnes * 100) / 100 }));
}

/* ------------------------------------------------------------------ */
/* Category meta                                                       */
/* ------------------------------------------------------------------ */

export const CATEGORY_META: Record<string, { icon: LucideIcon; color: string }> = {
  transport: { icon: TrainFront, color: "#1b4332" },
  energy: { icon: Zap, color: "#c87f4f" },
  food: { icon: Leaf, color: "#74a85f" },
  waste: { icon: Recycle, color: "#9aa17e" },
};
