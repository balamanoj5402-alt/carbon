import {
  BarChart3,
  ClipboardList,
  Compass,
  Lightbulb,
  RefreshCcw,
  ShieldCheck,
  Target,
  TrendingDown,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { Brand } from "@/components/ui/BrandIcons";

export interface NavItem {
  label: string;
  to: string;
}

export const NAV_ITEMS: NavItem[] = [
  { label: "Home", to: "/" },
  { label: "Calculator", to: "/calculator" },
  { label: "Dashboard", to: "/dashboard" },
  { label: "About", to: "/about" },
];

export const SOCIALS: { label: string; href: string; brand: Brand }[] = [
  { label: "X (Twitter)", href: "https://x.com/verdant_earth", brand: "x" },
  { label: "LinkedIn", href: "https://www.linkedin.com/company/verdant-earth", brand: "linkedin" },
  { label: "Instagram", href: "https://www.instagram.com/verdant.earth", brand: "instagram" },
  { label: "YouTube", href: "https://www.youtube.com/@verdant-earth", brand: "youtube" },
];

export const IMPACT_STATS = [
  { value: 128400, suffix: "+", label: "members measuring with Verdant" },
  { value: 41600, suffix: "", label: "tonnes of CO₂e tracked in 2025" },
  { value: 23, suffix: "%", label: "average footprint reduction in 6 months" },
  { value: 2400, suffix: "+", label: "team challenges completed" },
];

export const PARTNERS = [
  "GHG Protocol",
  "CDP",
  "Science Based Targets",
  "IPCC",
  "DEFRA",
  "Gold Standard",
  "Exiobase",
  "IEA",
];

export interface Feature {
  icon: LucideIcon;
  title: string;
  body: string;
}

export const FEATURES: Feature[] = [
  {
    icon: RefreshCcw,
    title: "Automatic, effortless tracking",
    body: "Connect utility, mobility and banking feeds once. Verdant converts raw activity into CO₂e in the background — no spreadsheets, no guesswork.",
  },
  {
    icon: BarChart3,
    title: "Category-level intelligence",
    body: "Every kilogram attributed to transport, home energy, food or waste. No black-box totals — you always see exactly what to work on.",
  },
  {
    icon: Target,
    title: "Adaptive monthly goals",
    body: "Targets that move with your life. Your monthly goals recalibrate as your data evolves, so ambition stays honest and achievable.",
  },
  {
    icon: Lightbulb,
    title: "A personal reduction playbook",
    body: "Recommendations ranked by what would actually move your number — each with an estimated annual saving and an effort rating.",
  },
  {
    icon: Users,
    title: "Team & household challenges",
    body: "Invite your household or office into friendly leagues. Shared wins, gentle nudges, zero shame — because change is easier together.",
  },
  {
    icon: ShieldCheck,
    title: "Verified carbon offsets",
    body: "When you can't cut further, offset with Gold Standard and VCS-registered projects — fully audited, transparently retired, never double-counted.",
  },
];

export interface Step {
  icon: LucideIcon;
  number: string;
  title: string;
  body: string;
}

export const STEPS: Step[] = [
  {
    icon: ClipboardList,
    number: "01",
    title: "Measure",
    body: "Answer a few questions about your travel, home energy, food and waste. Five minutes, no account needed — your estimate is computed instantly.",
  },
  {
    icon: Compass,
    number: "02",
    title: "Understand",
    body: "See every kilogram attributed to a category and benchmarked against your country's average and the 1.5°C-compatible path.",
  },
  {
    icon: TrendingDown,
    number: "03",
    title: "Reduce",
    body: "Get a ranked playbook of changes, track your progress month by month, and watch your footprint curve bend — and keep bending — downward.",
  },
];

export interface Testimonial {
  quote: string;
  name: string;
  role: string;
  initials: string;
  location: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      "Verdant turned climate guilt into an actual plan. In six months I've cut 1.4 tonnes — mostly by swapping my commute and two long-haul trips. The category breakdown is genuinely addictive.",
    name: "Maya Chen",
    role: "Product Designer",
    initials: "MC",
    location: "Amsterdam, NL",
  },
  {
    quote:
      "We rolled it out to forty engineers as a team challenge. The dashboard made reductions social without making them preachy — our office footprint dropped 21% in a single quarter.",
    name: "Dr. Jonas Weber",
    role: "Engineering Lead",
    initials: "JW",
    location: "Berlin, DE",
  },
  {
    quote:
      "Finally a tool that treats household energy like the serious lever it is. The renewable-tariff suggestion alone has paid for a decade of subscriptions.",
    name: "Priya Nair",
    role: "Sustainability Consultant",
    initials: "PN",
    location: "London, UK",
  },
];

export const VALUES = [
  {
    title: "Science-led, always",
    body: "Every factor we use is traceable to peer-reviewed research and official inventories — EPA, DEFRA, Exiobase and the IPCC. We cite our maths, and we update it.",
  },
  {
    title: "Radically honest",
    body: "No greenwashing, no vanity metrics. We show trade-offs, uncertainties and what we don't know — because trust is the only currency that matters in climate.",
  },
  {
    title: "Optimistic by default",
    body: "Climate data can feel paralysing. We design for momentum: small wins, visible progress, and proof that individual action compounds.",
  },
];

export const METHOD_SOURCES = [
  {
    name: "GHG Protocol",
    role: "Scope 1, 2 & 3 accounting framework",
  },
  {
    name: "DEFRA / BEIS",
    role: "Transport & energy conversion factors",
  },
  {
    name: "Exiobase",
    role: "Multi-regional input-output food & goods data",
  },
  {
    name: "IPCC AR6",
    role: "Global warming potentials & pathways",
  },
  {
    name: "US EPA",
    role: "Electricity grid emission factors",
  },
  {
    name: "IEA",
    role: "Energy systems & sector benchmarks",
  },
];

export const FAQ = [
  {
    q: "How accurate is the calculator?",
    a: "For an estimate built on twenty inputs, our calculator lands within ±15% of a detailed household audit for most users — better than the industry average. Factors are drawn from official inventories and updated quarterly. Syncing your actual utility and mobility data narrows the gap to roughly ±5%.",
  },
  {
    q: "Is my data private?",
    a: "Yes. Your data is encrypted in transit and at rest, never sold, and processed only to compute your footprint. You can export or delete everything at any time — we are GDPR compliant and independently audited annually.",
  },
  {
    q: "Do I need a paid plan to use the calculator?",
    a: "No. The calculator, your first report and the core dashboard are free forever. Paid plans unlock automatic data syncing, team challenges and advanced scenario planning.",
  },
  {
    q: "How do offsets work on Verdant?",
    a: "Only after you have reduced everything reasonably possible. You can retire credits from Gold Standard and VCS-registered projects, each with public retirement certificates so nothing is double-counted.",
  },
];
