import {
  Bike,
  Car,
  Globe,
  Home,
  Leaf,
  Plane,
  Recycle,
  Salad,
  Sprout,
  Target,
  TrendingDown,
  TreePine,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Monthly history (August 2025 – July 2026, sample member data)       */
/* ------------------------------------------------------------------ */

export interface MonthRecord {
  id: string;
  label: string;
  short: string;
  transport: number;
  energy: number;
  food: number;
  waste: number;
  total: number;
}

type RawMonth = [string, string, number, number, number, number];

const RAW_MONTHS: RawMonth[] = [
  ["Aug 2025", "Aug", 0.62, 0.58, 0.55, 0.3],
  ["Sep 2025", "Sep", 0.58, 0.54, 0.52, 0.28],
  ["Oct 2025", "Oct", 0.54, 0.47, 0.5, 0.27],
  ["Nov 2025", "Nov", 0.55, 0.55, 0.49, 0.27],
  ["Dec 2025", "Dec", 0.66, 0.62, 0.66, 0.37],
  ["Jan 2026", "Jan", 0.52, 0.49, 0.45, 0.26],
  ["Feb 2026", "Feb", 0.47, 0.44, 0.42, 0.22],
  ["Mar 2026", "Mar", 0.45, 0.42, 0.4, 0.21],
  ["Apr 2026", "Apr", 0.42, 0.38, 0.39, 0.2],
  ["May 2026", "May", 0.4, 0.35, 0.38, 0.19],
  ["Jun 2026", "Jun", 0.38, 0.33, 0.37, 0.16],
  ["Jul 2026", "Jul", 0.37, 0.34, 0.35, 0.12],
];

export const monthlyHistory: MonthRecord[] = RAW_MONTHS.map(
  ([label, short, transport, energy, food, waste], idx) => ({
    id: `m${idx}`,
    label,
    short,
    transport,
    energy,
    food,
    waste,
    total: transport + energy + food + waste,
  })
);

export const CATEGORIES = [
  { key: "transport", label: "Transport", color: "#1b4332", icon: Bike },
  { key: "energy", label: "Home energy", color: "#c87f4f", icon: Home },
  { key: "food", label: "Food", color: "#74a85f", icon: Salad },
  { key: "waste", label: "Waste", color: "#9aa17e", icon: Recycle },
] as const;

export const MEMBER = {
  name: "Ava",
  fullName: "Ava Lindqvist",
  month: "July 2026",
  city: "Copenhagen",
  streakMonths: 6,
  ytdTonnes: 9.88,
  targetMonthly: 1.1,
};

/* ------------------------------------------------------------------ */
/* Goals                                                               */
/* ------------------------------------------------------------------ */

export interface Goal {
  id: string;
  title: string;
  detail: string;
  current: number;
  target: number;
  unit: string;
  deadline: string;
  icon: LucideIcon;
  status: "On track" | "At risk" | "Done";
  progress: number; // 0-100, share of the journey completed
}

export const GOALS: Goal[] = [
  {
    id: "g1",
    title: "Reach 1.10 t monthly footprint",
    detail: "From a 1.32 t baseline in May",
    current: 1.18,
    target: 1.1,
    unit: "t CO₂e",
    deadline: "Sep 2026",
    icon: Target,
    status: "On track",
    progress: 64,
  },
  {
    id: "g2",
    title: "Drive 20% fewer car miles",
    detail: "Baseline 335 mi / month",
    current: 268,
    target: 214,
    unit: "mi / mo",
    deadline: "Oct 2026",
    icon: Car,
    status: "At risk",
    progress: 55,
  },
  {
    id: "g3",
    title: "Low-meat 22 days a month",
    detail: "Currently 18 days — keep climbing",
    current: 18,
    target: 22,
    unit: "days",
    deadline: "Dec 2026",
    icon: Salad,
    status: "On track",
    progress: 82,
  },
  {
    id: "g4",
    title: "Recycle 60% of household waste",
    detail: "Composting trial started in June",
    current: 46,
    target: 60,
    unit: "%",
    deadline: "Nov 2026",
    icon: Recycle,
    status: "On track",
    progress: 77,
  },
];

/* ------------------------------------------------------------------ */
/* Badges                                                              */
/* ------------------------------------------------------------------ */

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  earned: boolean;
  earnedDate?: string;
  hint: string;
}

export const BADGES: Badge[] = [
  {
    id: "b1",
    title: "First Steps",
    description: "Completed your first full footprint audit and generated a reduction plan.",
    icon: Leaf,
    earned: true,
    earnedDate: "Mar 2026",
    hint: "Earned by finishing the calculator",
  },
  {
    id: "b2",
    title: "Consistent",
    description: "Six consecutive months of footprint reduction — momentum compounding.",
    icon: TrendingDown,
    earned: true,
    earnedDate: "Jul 2026",
    hint: "Reduce month-over-month 6 times",
  },
  {
    id: "b3",
    title: "First Tonne",
    description: "Retired one verified tonne of CO₂e through Gold Standard offsets.",
    icon: TreePine,
    earned: true,
    earnedDate: "Jun 2026",
    hint: "Offset your first tonne",
  },
  {
    id: "b4",
    title: "Green Commuter",
    description: "Thirty days of low-carbon commuting — bike, rail or walk.",
    icon: Bike,
    earned: true,
    earnedDate: "May 2026",
    hint: "30 days of clean commuting",
  },
  {
    id: "b5",
    title: "Plant Power",
    description: "Thirty consecutive days of plant-based eating.",
    icon: Sprout,
    earned: false,
    hint: "Eat plant-based for 30 days",
  },
  {
    id: "b6",
    title: "Frequent Flyer, Less",
    description: "Skipped a long-haul flight you would normally have taken.",
    icon: Plane,
    earned: false,
    hint: "Skip one long-haul trip",
  },
  {
    id: "b7",
    title: "Home Hero",
    description: "Switched your household to a 100% renewable electricity tariff.",
    icon: Home,
    earned: false,
    hint: "Switch to a renewable tariff",
  },
  {
    id: "b8",
    title: "Net Zero Pioneer",
    description: "Finished a calendar month under 1.0 t CO₂e. The top of the mountain.",
    icon: Globe,
    earned: false,
    hint: "Finish a month under 1.0 t",
  },
];

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

export function deltaPct(current: number, previous: number): number {
  if (previous === 0) return 0;
  return ((current - previous) / previous) * 100;
}

const MONTH_ORDER = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Sortable numeric key from a "Aug 2025" style label. */
export function monthKey(label: string): number {
  const [m, y] = label.split(" ");
  return (parseInt(y, 10) || 0) * 12 + MONTH_ORDER.indexOf(m);
}

/** Consecutive month-over-month reductions at the end of the series. */
export function reductionStreak(records: MonthRecord[]): number {
  let streak = 0;
  for (let i = records.length - 1; i > 0; i--) {
    if (records[i].total < records[i - 1].total) streak++;
    else break;
  }
  return streak;
}

export const currentMonth = monthlyHistory[monthlyHistory.length - 1];
export const previousMonth = monthlyHistory[monthlyHistory.length - 2];
export const monthDelta = deltaPct(currentMonth.total, previousMonth.total);
export const ytdStartIdx = monthlyHistory.findIndex((m) => m.label.startsWith("Jan"));
export const ytdTotal = monthlyHistory
  .slice(ytdStartIdx)
  .reduce((sum, m) => sum + m.total, 0);
